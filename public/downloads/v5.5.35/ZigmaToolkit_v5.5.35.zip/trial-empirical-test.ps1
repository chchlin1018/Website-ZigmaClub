﻿# ============================================================================
# Zigma Trial User Empirical Test (read-only data collection)
# ============================================================================
#
# Purpose: trial user (洪明偉) 跑完此 script 一鍵收集 v5.5.35 端對端 FACT
#   1. 環境 FACT dump (OS / PS / Revit 2027 / Defender state)
#   2. Plugin install FACT (DLL path/size/SHA8/version + dependencies)
#   3. Defender quarantine state (Layer 1 PS cmdlet + Layer 2 MpCmdRun.exe)
#   4. .ps1 self-test (-Verify mode)
#   5. Desktop\Zigma-Empirical-<computer>-<timestamp>.txt + zip
#   6. 自動嘗試 Outlook COM 附檔開新郵件 (fallback mailto + Explorer)
#
# Read-only · 不還原任何檔案 · 不修改系統設定 · admin 非必要 (但建議)
#
# Zigma USD Connector v5.5.35 Pre-Beta · 2026-05-28 +0800 · Reality Matrix AI Inc.
# ============================================================================

$ErrorActionPreference = 'Continue'
$startTs = Get-Date

# === Output path ===
$timestamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$computer = $env:COMPUTERNAME
$desktop = [Environment]::GetFolderPath('Desktop')
$outputDir = if (Test-Path $desktop) { $desktop } else { [Environment]::GetFolderPath('MyDocuments') }
$txtPath = Join-Path $outputDir "Zigma-Empirical-$computer-$timestamp.txt"
$zipPath = Join-Path $outputDir "Zigma-Empirical-$computer-$timestamp.zip"

# === Output buffer ===
$lines = [System.Collections.ArrayList]::new()
function Add-Line { param([string]$t) [void]$lines.Add($t); Write-Host $t }
function Add-Section { param([string]$h) Add-Line ''; Add-Line ('=' * 60); Add-Line "  $h"; Add-Line ('=' * 60) }

# === Banner ===
Add-Line "Zigma USD Connector v5.5.35 Pre-Beta · Empirical Test Report"
Add-Line "============================================================="
Add-Line "Computer  : $computer"
Add-Line "User      : $env:USERNAME"
Add-Line "Generated : $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss zzz')"
Add-Line "Report    : $txtPath"

# === [1] Environment FACT ===
Add-Section '[1] 環境 FACT (Environment)'
Add-Line "Windows OS    : $((Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue).Caption) ($([System.Environment]::OSVersion.Version))"
Add-Line "Windows Build : $((Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue).BuildNumber)"
Add-Line "Architecture  : $env:PROCESSOR_ARCHITECTURE"
Add-Line "PowerShell    : $($PSVersionTable.PSVersion) · Edition=$($PSVersionTable.PSEdition)"
Add-Line "Culture       : $((Get-Culture).Name) · UICulture=$((Get-UICulture).Name)"
$net = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full' -ErrorAction SilentlyContinue).Release
Add-Line ".NET Framework Release: $net"
$dotnetExe = Get-Command dotnet -ErrorAction SilentlyContinue
if ($dotnetExe) {
    $dotnetVer = & dotnet --list-runtimes 2>$null | Out-String
    Add-Line ".NET Runtimes :"
    foreach ($l in ($dotnetVer -split "`n" | Where-Object { $_ -match 'NETCore' -or $_ -match 'WindowsDesktop' })) { Add-Line "  $($l.Trim())" }
}

# === [2] Revit 2027 install FACT ===
Add-Section '[2] Revit 2027 FACT'
$revitExe = 'C:\Program Files\Autodesk\Revit 2027\Revit.exe'
if (Test-Path $revitExe) {
    $rInfo = Get-Item $revitExe
    Add-Line "Revit.exe     : $revitExe"
    Add-Line "Size          : $($rInfo.Length) bytes"
    Add-Line "Version       : $($rInfo.VersionInfo.FileVersion)"
    Add-Line "Modified      : $($rInfo.LastWriteTime)"
} else {
    Add-Line "Revit.exe     : MISSING ($revitExe)"
}
$revitRunning = Get-Process Revit -ErrorAction SilentlyContinue
Add-Line "Revit running : $(if ($revitRunning) { 'YES · PID ' + ($revitRunning.Id -join ',') } else { 'NO' })"

# === [3] Zigma Plugin install FACT ===
Add-Section '[3] Zigma Plugin Install FACT'
$addinPaths = @(
    'C:\Program Files\Autodesk\Revit\Addins\2027\Zigma',
    'C:\Program Files\Autodesk\Revit\Addins\2027'
)
$zigmaFound = $false
foreach ($p in $addinPaths) {
    $dll = Join-Path $p 'Zigma.UsdConnector.dll'
    if (Test-Path $dll) {
        $zigmaFound = $true
        $info = Get-Item $dll
        $sha = (Get-FileHash $dll -Algorithm SHA256).Hash.Substring(0, 8)
        Add-Line "[FOUND] $dll"
        Add-Line "  Size        : $($info.Length) bytes"
        Add-Line "  SHA8        : $sha"
        Add-Line "  Modified    : $($info.LastWriteTime)"
        Add-Line "  Version     : $($info.VersionInfo.FileVersion) · Product=$($info.VersionInfo.ProductVersion)"
        # Other companion files
        $companions = @('ZigmaRenderUtil.dll', 'zigma-worker.exe', 'zigma-worker.vmp.exe', 'MachineKeyGenerator.exe', 'MachineKeyGenerator.vmp.exe', 'ZigmaWpfViewer.dll')
        # cont-33 v5.5.35 · BUG-1 fix per L304 · Richard FACT-report 3 files reported same SHA · add verbose path log + Get-FileHash error surface + explicit variable scope
        foreach ($c in $companions) {
            $cp = Join-Path $p $c
            if (Test-Path $cp) {
                $ci = Get-Item $cp
                $csha = 'ERR_UNKNOWN'
                try {
                    $hashResult = Get-FileHash -LiteralPath $cp -Algorithm SHA256 -ErrorAction Stop
                    if ($hashResult -and $hashResult.Hash) {
                        $csha = $hashResult.Hash.Substring(0, 8)
                    } else {
                        $csha = 'ERR_NULL_HASH'
                    }
                } catch {
                    $errMsg = $_.Exception.Message
                    if ($errMsg.Length -gt 30) { $errMsg = $errMsg.Substring(0, 30) }
                    $csha = "ERR_$errMsg"
                }
                # 2nd Defender PUA scan workaround · file may be locked · retry with FileStream Read
                if ($csha -like 'ERR_*') {
                    try {
                        $fs = [System.IO.File]::Open($cp, 'Open', 'Read', 'ReadWrite')
                        $hashAlg = [System.Security.Cryptography.SHA256]::Create()
                        $hashBytes = $hashAlg.ComputeHash($fs)
                        $fs.Close()
                        $hashAlg.Dispose()
                        $hexStr = -join ($hashBytes | ForEach-Object { '{0:X2}' -f $_ })
                        $csha = $hexStr.Substring(0, 8) + '_FS'
                    } catch { }
                }
                Add-Line "  [COMP]    $c"
                Add-Line "            Path : $cp"
                Add-Line "            Size : $($ci.Length) bytes"
                Add-Line "            SHA8 : $csha"
                Add-Line "            Mtime: $($ci.LastWriteTime)"
            }
        }
        $addinFile = Join-Path $p 'Zigma.UsdConnector.addin'
        if (-not (Test-Path $addinFile)) {
            $addinFile = 'C:\Program Files\Autodesk\Revit\Addins\2027\Zigma.UsdConnector.addin'
        }
        if (Test-Path $addinFile) {
            Add-Line "  [MANIFEST] $addinFile · $($((Get-Item $addinFile)).Length) bytes"
        }
        break
    }
}
if (-not $zigmaFound) { Add-Line "[X] Plugin NOT FOUND in any expected addin path" }

# License token state
# v5.5.35: cover current license storage paths (was checking only legacy paths)
Add-Section '[3.1] License Activation FACT'
$lpaths = @(
    @{ Path = "$env:LOCALAPPDATA\Zigma\license-v4.b64";       Kind = 'license token' },
    @{ Path = "$env:APPDATA\Zigma\revit_addin_cache.dat";     Kind = 'license cache (encrypted)' },
    @{ Path = "$env:LOCALAPPDATA\Zigma\license.dat";          Kind = 'V1 legacy' },
    @{ Path = "$env:APPDATA\Zigma\license.dat";               Kind = 'V1 legacy alt' },
    @{ Path = "$env:LOCALAPPDATA\Zigma\viewer_features.token"; Kind = 'V3 viewer features' }
)
$licFound = $false
foreach ($lp in $lpaths) {
    if (Test-Path $lp.Path) {
        $li = Get-Item $lp.Path
        Add-Line "[LIC] $($lp.Path) · $($li.Length) bytes · $($lp.Kind) · modified=$($li.LastWriteTime)"
        $licFound = $true
    }
}
# Registry activation flag (V1 worker writes HKCU when activate succeeds)
try {
    $regKey = Get-ItemProperty -Path 'HKCU:\Software\RealityMatrix\Zigma\License' -ErrorAction Stop
    if ($regKey.Activated -eq '1') {
        Add-Line "[REG] HKCU\Software\RealityMatrix\Zigma\License · Activated=1 · Role=$($regKey.Role) · ExpiryDays=$($regKey.ExpiryDays)"
        $licFound = $true
    }
} catch {
    # registry key absent · NOT a fail · means never activated via V1 worker (V4 path independent)
}
if (-not $licFound) {
    Add-Line "[NONE] No license files OR registry activation found · plugin in Unlicensed state"
}

# === [4] Defender state FACT ===
Add-Section '[4] Microsoft Defender FACT'
$defModule = $null
try { $defModule = Get-Module -ListAvailable -Name Defender, ConfigDefender -ErrorAction SilentlyContinue } catch { }
$modAvail = (($defModule | Measure-Object).Count -gt 0)
Add-Line "Defender PS Module Available : $modAvail"
if ($modAvail) {
    foreach ($m in $defModule) { Add-Line "  Module: $($m.Name) v$($m.Version) Path=$($m.ModuleBase)" }
    try {
        Import-Module $defModule[0].Name -Force -ErrorAction Stop
        Add-Line "  Import-Module $($defModule[0].Name) : OK"
    } catch {
        Add-Line "  Import-Module FAIL: $($_.Exception.Message)"
    }
}
$cmdletList = @('Restore-MpThreat', 'Get-MpThreat', 'Get-MpThreatDetection', 'Add-MpPreference', 'Get-MpPreference', 'Get-MpComputerStatus')
foreach ($c in $cmdletList) {
    $exists = ((Get-Command $c -ErrorAction SilentlyContinue) -ne $null)
    Add-Line "  cmdlet $c : $exists"
}

# MpCmdRun.exe FACT
$mpCmdRun = "$env:ProgramFiles\Windows Defender\MpCmdRun.exe"
if (-not (Test-Path $mpCmdRun)) {
    $platformDir = "$env:ProgramData\Microsoft\Windows Defender\Platform"
    if (Test-Path $platformDir) {
        $latest = Get-ChildItem $platformDir -Directory -ErrorAction SilentlyContinue | Sort-Object Name -Descending | Select-Object -First 1
        if ($latest) {
            $candidate = Join-Path $latest.FullName 'MpCmdRun.exe'
            if (Test-Path $candidate) { $mpCmdRun = $candidate }
        }
    }
}
Add-Line "MpCmdRun.exe path : $mpCmdRun"
$mpAvail = (Test-Path $mpCmdRun)
Add-Line "MpCmdRun.exe exists : $mpAvail"
if ($mpAvail) {
    $mpInfo = Get-Item $mpCmdRun
    Add-Line "  Size=$($mpInfo.Length) bytes · Version=$($mpInfo.VersionInfo.FileVersion)"
    Add-Line "  Running: MpCmdRun.exe -Restore -ListAll (may require admin · output below):"
    $mpOut = & $mpCmdRun -Restore -ListAll 2>&1
    $mpEc = $LASTEXITCODE
    Add-Line "  Exit code: $mpEc"
    foreach ($l in ($mpOut | Out-String).Trim() -split "`r?`n") { Add-Line "  | $l" }
}

# Defender real-time + exclusions
try {
    $mpPref = Get-MpPreference -ErrorAction Stop
    Add-Line "Defender RealTime Disabled : $($mpPref.DisableRealtimeMonitoring)"
    if ($mpPref.ExclusionPath) {
        Add-Line "Defender ExclusionPath ($($mpPref.ExclusionPath.Count) entries):"
        foreach ($e in $mpPref.ExclusionPath) {
            $isZigma = $e -match 'Zigma|Autodesk\\Revit|Reality Matrix'
            $mark = if ($isZigma) { '[Z]' } else { '   ' }
            Add-Line "  $mark $e"
        }
    } else {
        Add-Line "Defender ExclusionPath : (none)"
    }
} catch {
    Add-Line "Get-MpPreference FAIL: $($_.Exception.Message)"
}

# Threats
try {
    $threats = @(Get-MpThreat -ErrorAction SilentlyContinue)
    Add-Line "Get-MpThreat count : $($threats.Count)"
    foreach ($t in $threats) { Add-Line "  Threat: $($t.ThreatName) · Resources=$($t.Resources -join '; ')" }
} catch { Add-Line "Get-MpThreat FAIL: $($_.Exception.Message)" }

# === [5] .ps1 self-test ===
Add-Section '[5] restore-from-defender-quarantine.ps1 -Verify SELF-TEST'
$selfPs1 = Join-Path $PSScriptRoot 'restore-from-defender-quarantine.ps1'
if (Test-Path $selfPs1) {
    Add-Line "Self-test target : $selfPs1"
    $b = [System.IO.File]::ReadAllBytes($selfPs1) | Select-Object -First 3
    $bom = ($b[0] -eq 239 -and $b[1] -eq 187 -and $b[2] -eq 191)
    Add-Line "  BOM (EF BB BF)   : $bom"
    Add-Line "  Size             : $((Get-Item $selfPs1).Length) bytes"
    Add-Line "  -Verify mode output (no actual restore):"
    $verifyOut = & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $selfPs1 -Verify 2>&1
    $verifyEc = $LASTEXITCODE
    Add-Line "  Exit code: $verifyEc"
    foreach ($l in ($verifyOut | Out-String).Trim() -split "`r?`n") { Add-Line "  | $l" }
} else {
    Add-Line "[X] $selfPs1 NOT FOUND in same folder · skip self-test"
}

# === [6] Summary ===
Add-Section '[6] Summary'
$status_revit = if (Test-Path $revitExe) { 'PASS' } else { 'FAIL' }
$status_plugin = if ($zigmaFound) { 'PASS' } else { 'FAIL' }
$status_defender_layer1 = if ($modAvail -and ((Get-Command Restore-MpThreat -ErrorAction SilentlyContinue) -ne $null)) { 'PASS' } else { 'FALLBACK_NEEDED' }
$status_defender_layer2 = if ($mpAvail) { 'PASS' } else { 'FAIL' }
Add-Line "Revit 2027 install   : $status_revit"
Add-Line "Zigma Plugin install : $status_plugin"
Add-Line "Defender Layer 1 (PS cmdlet)    : $status_defender_layer1"
Add-Line "Defender Layer 2 (MpCmdRun.exe) : $status_defender_layer2"
$dur = (Get-Date) - $startTs
Add-Line "Collection duration : $([math]::Round($dur.TotalSeconds, 1)) sec"
Add-Line ''
Add-Line "謝謝協助 . 請將桌面的 Zigma-Empirical-*.zip 用 Email 附件寄回:"
Add-Line "  michael.lin@realitymatrixai.com"

# === Write file + zip ===
$lines | Out-File -FilePath $txtPath -Encoding UTF8 -Force
Write-Host ""
Write-Host "[OK] 報告已儲存: $txtPath" -ForegroundColor Green
Compress-Archive -Path $txtPath -DestinationPath $zipPath -Force
Write-Host "[OK] 壓縮檔已建立: $zipPath" -ForegroundColor Green

# === Auto-open Notepad ===
Start-Process notepad.exe -ArgumentList "`"$txtPath`""

# === Auto-attach + launch email · Outlook COM first · mailto fallback ===
$subject = "[Zigma Pre-Beta v5.5.35] Empirical Test Report · $computer · $timestamp"
$body = @"
您好 Michael,

附上 Zigma USD Connector v5.5.35 Pre-Beta 端對端 Empirical Test 結果。

電腦 : $computer
時間 : $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss zzz')
檔案 : $zipPath

請查收。

--
$env:USERNAME
"@

$emailSent = $false

# v5.5.35: detect new Outlook (Win11 UWP) · skip COM (NOT supported by design)
# FACT-cite (Michael ProArt empirical 2026-05-28): Win11 default = new Outlook UWP · no COM ·
#   `New-Object -ComObject Outlook.Application` throws · waste of try/catch latency.
# Classic Outlook desktop registers ProgID "Outlook.Application" in HKCR · new Outlook doesn't.
$hasComOutlook = $false
try {
    $progIdType = [Type]::GetTypeFromProgID('Outlook.Application', $false)
    if ($progIdType) { $hasComOutlook = $true }
} catch { }

if ($hasComOutlook) {
    # Classic Outlook present · try COM (could still fail if Outlook not running OR policy blocks)
    try {
        $outlook = New-Object -ComObject Outlook.Application -ErrorAction Stop
        $mail = $outlook.CreateItem(0)  # 0 = olMailItem
        $mail.To = 'michael.lin@realitymatrixai.com'
        $mail.Subject = $subject
        $mail.Body = $body
        $mail.Attachments.Add($zipPath) | Out-Null
        $mail.Display($false)  # show window · don't auto-send
        Write-Host "[OK] Outlook 草稿已開啟並附檔 . 請按「傳送」寄出" -ForegroundColor Green
        $emailSent = $true
    } catch {
        Write-Host "[INFO] Outlook COM 失敗 (Classic Outlook 已裝但 COM 拒) . fallback mailto: + Explorer" -ForegroundColor Yellow
    }
} else {
    Write-Host "[INFO] Win11 new Outlook (UWP) 偵測到 . 不支援 COM 附檔 . 走 mailto: + Explorer 手動拖檔" -ForegroundColor Yellow
}

if (-not $emailSent) {
    # Fallback . open default mail client via mailto: (no attachment per RFC 6068)
    # v5.5.35: use [uri]::EscapeDataString (BCL · always available)
    # instead of [System.Web.HttpUtility]::UrlEncode (System.Web NOT auto-loaded in PS 5.1 Desktop)
    $bodyEnc = [uri]::EscapeDataString($body + "`n`n[請手動附上 $zipPath]")
    $subjEnc = [uri]::EscapeDataString($subject)
    $mailto = "mailto:michael.lin@realitymatrixai.com?subject=$subjEnc&body=$bodyEnc"
    try { Start-Process $mailto -ErrorAction Stop } catch { }
    # Open Explorer with zip pre-selected so user can drag-drop into mail client
    try { Start-Process explorer.exe -ArgumentList "/select,`"$zipPath`"" -ErrorAction Stop } catch { }
    Write-Host "[INFO] 已開啟預設郵件 + Explorer (檔案已選取)" -ForegroundColor Yellow
    Write-Host "      請手動拖曳 $zipPath 到郵件附件後寄出" -ForegroundColor Yellow
}

exit 0
