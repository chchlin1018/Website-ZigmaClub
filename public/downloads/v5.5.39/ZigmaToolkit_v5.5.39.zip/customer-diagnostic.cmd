@echo off
REM ============================================================================
REM Zigma Diagnostic Tool · Reality Matrix AI Inc. · License Troubleshooting
REM ============================================================================
REM
REM Usage (3 steps):
REM   1. Place both files (customer-diagnostic.cmd + customer-diagnostic.ps1)
REM      in the SAME folder
REM   2. Double-click this file (customer-diagnostic.cmd)
REM   3. Wait ~30 sec · A Zigma-Diagnostic-*.txt will be auto-generated on
REM      Desktop · Email it back to Michael
REM
REM Auto handling:
REM   - Bypass PowerShell ExecutionPolicy restriction
REM   - No admin required (most checks are read-only)
REM   - Does NOT modify any system settings · pure read-only forensic
REM
REM Auto-locale: zh-TW / en / ja based on system UI culture (fallback en)
REM
REM Zigma USD Connector v5.5.39 Pre-Beta · 2026-05-28 · Reality Matrix AI Inc.
REM ============================================================================

setlocal
chcp 65001 >nul

REM === i18n locale detection (zh / ja / en) ===
set "CULTURE=en"
for /f "tokens=*" %%i in ('powershell -NoProfile -Command "$c=(Get-Culture).Name; if($c -match '^zh'){'zh'}elseif($c -match '^ja'){'ja'}else{'en'}"') do set "CULTURE=%%i"

echo.
echo =====================================================
if "%CULTURE%"=="zh" (
    echo   Zigma 診斷工具 . License 故障排除
    echo   Reality Matrix AI Inc.
) else if "%CULTURE%"=="ja" (
    echo   Zigma 診断ツール . License トラブルシューティング
    echo   Reality Matrix AI Inc.
) else (
    echo   Zigma Diagnostic Tool . License Troubleshooting
    echo   Reality Matrix AI Inc.
)
echo =====================================================
echo.
if "%CULTURE%"=="zh" (
    echo 正在啟動診斷腳本 . 約需 30 秒 . 請稍候...
) else if "%CULTURE%"=="ja" (
    echo 診断スクリプトを起動中 . 約 30 秒 . お待ちください...
) else (
    echo Starting diagnostic script . takes ~30 sec . please wait...
)
echo.

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0customer-diagnostic.ps1"
set EXITCODE=%ERRORLEVEL%

echo.
echo =====================================================
if %EXITCODE% EQU 0 (
    if "%CULTURE%"=="zh" (
        echo   診斷完成 [OK]
        echo   結果已自動儲存至桌面 . 並自動開啟 Notepad
        echo   請將 .txt 檔案以 Email 附件寄回:
        echo     michael.lin@realitymatrixai.com
    ) else if "%CULTURE%"=="ja" (
        echo   診断完了 [OK]
        echo   結果はデスクトップに自動保存され . Notepad が自動で開きます
        echo   .txt ファイルを Email 添付で返送してください:
        echo     michael.lin@realitymatrixai.com
    ) else (
        echo   Diagnostic complete [OK]
        echo   Result auto-saved to Desktop . Notepad opened automatically
        echo   Please email the .txt file back to:
        echo     michael.lin@realitymatrixai.com
    )
) else (
    if "%CULTURE%"=="zh" (
        echo   診斷腳本執行失敗 [X] ^(exit code: %EXITCODE%^)
        echo   請聯絡 michael.lin@realitymatrixai.com
    ) else if "%CULTURE%"=="ja" (
        echo   診断スクリプト実行失敗 [X] ^(exit code: %EXITCODE%^)
        echo   michael.lin@realitymatrixai.com までご連絡ください
    ) else (
        echo   Diagnostic script failed [X] ^(exit code: %EXITCODE%^)
        echo   Please contact michael.lin@realitymatrixai.com
    )
)
echo =====================================================
echo.
pause
endlocal
