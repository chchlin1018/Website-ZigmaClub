@echo off
REM ============================================================================
REM Zigma Trial User Empirical Test - One-Click Wrapper (i18n zh/ja/en)
REM ============================================================================
REM Purpose: collect end-to-end empirical FACT (env / Plugin install / Defender)
REM Usage:   double-click this .cmd · wait 30-60 sec · check Desktop output
REM Output:  Zigma-Empirical-<computer>-<timestamp>.txt + .zip + Outlook draft
REM Modes:   read-only · no system changes · admin recommended for full Defender
REM Version: v5.5.39 Pre-Beta · 2026-05-28 +0800 · Reality Matrix AI Inc.
REM
REM IMPORTANT: REM and echo lines BEFORE `chcp 65001` MUST avoid CJK 3-byte
REM   UTF-8 chars · cmd.exe on Chinese Windows reads with system CP950 codepage
REM   and mis-parses UTF-8 multi-byte · Latin-1 (e.g. middle-dot) is safe ·
REM   CJK kanji is NOT · model after customer-diagnostic.cmd structure.
REM ============================================================================

setlocal
chcp 65001 >nul

REM === i18n locale detection (zh / ja / en) ===
set "CULTURE=en"
for /f "tokens=*" %%i in ('powershell -NoProfile -Command "$c=(Get-Culture).Name; if($c -match '^zh'){'zh'}elseif($c -match '^ja'){'ja'}else{'en'}"') do set "CULTURE=%%i"

echo.
echo =====================================================
if "%CULTURE%"=="zh" (
    echo   Zigma 端對端 Empirical Test
    echo   Reality Matrix AI Inc. v5.5.39 Pre-Beta
) else if "%CULTURE%"=="ja" (
    echo   Zigma エンドツーエンド エンピリカルテスト
    echo   Reality Matrix AI Inc. v5.5.39 Pre-Beta
) else (
    echo   Zigma End-to-End Empirical Test
    echo   Reality Matrix AI Inc. v5.5.39 Pre-Beta
)
echo =====================================================
echo.
if "%CULTURE%"=="zh" (
    echo 正在收集 FACT 資料 . 約需 30-60 秒 . 請稍候 . 勿關閉視窗
) else if "%CULTURE%"=="ja" (
    echo FACT データを収集中 . 30-60 秒 . お待ちください . 閉じないでください
) else (
    echo Collecting FACT data . takes 30-60 sec . please wait . do NOT close window
)
echo.

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0trial-empirical-test.ps1"
set EXITCODE=%ERRORLEVEL%

echo.
echo =====================================================
if %EXITCODE% EQU 0 (
    if "%CULTURE%"=="zh" (
        echo   收集完成 [OK]
        echo   結果已儲存至桌面 . 並自動開啟 Notepad
        echo   請將 Zigma-Empirical-*.zip 以 Email 附件寄回:
        echo     michael.lin@realitymatrixai.com
    ) else if "%CULTURE%"=="ja" (
        echo   収集完了 [OK]
        echo   結果はデスクトップに保存され . Notepad が自動で開きます
        echo   Zigma-Empirical-*.zip を Email 添付で送付してください:
        echo     michael.lin@realitymatrixai.com
    ) else (
        echo   Collection complete [OK]
        echo   Result saved to Desktop . Notepad auto-opened
        echo   Please email Zigma-Empirical-*.zip as attachment to:
        echo     michael.lin@realitymatrixai.com
    )
) else (
    if "%CULTURE%"=="zh" (
        echo   收集失敗 [X] ^(exit code: %EXITCODE%^)
        echo   請聯絡 michael.lin@realitymatrixai.com 並附上錯誤訊息
    ) else if "%CULTURE%"=="ja" (
        echo   収集失敗 [X] ^(exit code: %EXITCODE%^)
        echo   michael.lin@realitymatrixai.com まで連絡してください
    ) else (
        echo   Collection failed [X] ^(exit code: %EXITCODE%^)
        echo   Please contact michael.lin@realitymatrixai.com with error message
    )
)
echo =====================================================
echo.
pause
endlocal
