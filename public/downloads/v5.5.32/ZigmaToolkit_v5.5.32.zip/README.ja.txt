================================================================
  Zigma USD Connector · Pre-Beta v5.5.32
  インストールガイド + ライセンス・トラブルシューティング (日本語)
  Reality Matrix AI Inc. · 実矩科技 · 2026-05-28
================================================================

⚠️ NDA 機密情報 · NDA 未締結の第三者への転送を禁ずる

────────────────────────────────────────────────────────────────
  v5.5.32 新機能 · About ダイアログのワンクリック 3 ボタン
────────────────────────────────────────────────────────────────

   Revit を起動 -> Zigma USD リボン ->「About Zigma」をクリック。
   ダイアログ内 (言語 RadioButton の下) に 3 つの新ボタンを追加:

     • Diagnostic (診断レポート)
       内部で trial-empirical-test.cmd を実行 · デスクトップに .txt
       レポートを生成 · michael.lin@realitymatrixai.com 宛ての
       メール下書きを .txt 添付付きで自動オープン。

     • Restore Quarantine (隔離復元)
       内部で restore-from-defender-quarantine.ps1 を管理者
       UAC プロンプト付きで実行 · 3 層フォールバックチェーン:
       PowerShell cmdlet -> MpCmdRun.exe -> 手動 UI 操作。

     • Open README (README を開く)
       対応言語の README.txt (英 / 繁中 / 日) を Notepad で開く。
       License 認証状態に関係なくいつでも使用可能。

   既定の動作 (v5.5.32):
     • License 認証済み: Diagnostic + Restore Quarantine は Disabled (グレー)
     • License 認証失敗: 2 ボタン Enabled + 赤字 Step 1 / Step 2 案内

   ボタンのラベルはダイアログ上部の言語 RadioButton
   (English / 中文 / 日本語) に追従し即時切り替わります。
   .cmd / .ps1 の手動実行 path は引き続き完全サポート (§5 参照)。

   ⚠️ trial user empirical verification pending round-3 ·
      not yet 100% guaranteed · About ダイアログのボタンが
      正常動作しない場合は §5 の手動 path をご利用ください。

────────────────────────────────────────────────────────────────
  目次
────────────────────────────────────────────────────────────────

    §1  システム要件
    §2  インストール
    §3  起動確認
    §4  ライセンスアクティベーション手順
    §5  トラブルシューティング
        §5.1  ライセンス失敗 · 赤字「Defender 隔離」リカバリーダイアログ
        §5.2  ライセンス失敗 · 橙字「キー長エラー」
        §5.3  Revit にリボンが表示されない
        §5.4  3D ビューアー起動クラッシュ
    §6  アンインストール
    §7  サポート連絡
    §8  NDA リマインダー

================================================================
  §1 システム要件
================================================================

>>> 1.1 オペレーティングシステム
   • Windows 11 (推奨 · 完全テスト済み)
   • Windows 10 22H2 以降

>>> 1.2 必須ソフトウェア

   | 項目                            | バージョン要件 | 備考                  |
   |---------------------------------|----------------|-----------------------|
   | Autodesk Revit                  | 2027 (唯一対応) | 2026 以前はサポート対象外 |
   | .NET 10 Desktop Runtime         | 10.0.0+        | プラグイン + ビューアー必須 |
   | Visual C++ 2022 Redistributable | x64 最新版     | ワーカー必須          |

>>> 1.3 推奨ハードウェア
   • CPU: 8 コア以上 (Intel i7 / AMD Ryzen 7 もしくはそれ以上)
   • RAM: 16 GB 以上 (大規模 RVT モデルには 32 GB 推奨)
   • ディスク: 約 600 MB の空き容量
   • GPU: DirectX 11 対応 (3D ビューアーで必要)

>>> 1.4 .NET 10 Desktop Runtime のインストール確認

   PowerShell で実行:
      dotnet --list-runtimes

   下記のような出力が表示されるはずです:
      Microsoft.WindowsDesktop.App 10.0.0 [...]

   未インストールの場合は https://dotnet.microsoft.com/download/dotnet/10.0
   から ".NET Desktop Runtime 10.0" (x64) をダウンロードしてインストールしてください。

────────────────────────────────────────────────────────────────
  §2 インストール
────────────────────────────────────────────────────────────────

>>> 2.1 インストール前準備
   1. Revit 2027 を完全に終了する (タスクマネージャーで Revit.exe が無いことを確認)
   2. Revit が C:\Program Files\Autodesk\Revit 2027\ にインストールされていることを確認

   ⚠️ Defender 除外設定 (ほとんどの場合は MSI が自動処理):

      v5.5.32 MSI はインストール時に 7 件の Defender 除外パスを自動追加します
      (WiX CustomAction · ユーザーの手動操作は不要)。

      ご利用の企業環境で Defender が GPO によりロックされている場合、
      自動除外が無効化される可能性があります。
      その場合は管理者権限の PowerShell で手動実行してください:

         Add-MpPreference -ExclusionPath "C:\Program Files\Autodesk\Revit\Addins\2027"
         Add-MpPreference -ExclusionPath "C:\Program Files\Autodesk\Revit\Addins\2027\Zigma"

>>> 2.2 MSI インストーラーの実行
   1. "ZigmaSetup_v5.5.32_Pre-Beta.msi" をダブルクリック
   2. UAC プロンプト →「はい」をクリック (perMachine インストール · 管理者権限が必要)
   3. Pre-Beta NDA EULA を確認 →「同意する」にチェック
   4. インストールパスがデフォルト値であることを確認し「Install」をクリック
   5. インストールには約 1〜3 分かかります (ディスク速度に依存)

>>> 2.3 インストール完了の確認

   エクスプローラーを開き、以下のファイルが存在することを確認してください:

      C:\Program Files\Autodesk\Revit\Addins\2027\
      ├── Zigma.UsdConnector.addin              ← Revit マニフェスト (ルート直下)
      └── Zigma\                                 ← Plugin ファイルは vendor サブフォルダ内
          ├── Zigma.UsdConnector.dll
          ├── ZigmaRenderUtil.dll
          ├── tools\                            ← トラブルシューティングツール
          │   ├── README.txt                   (インデックス · 3 言語入口)
          │   ├── README.zh-TW.txt
          │   ├── README.en.txt
          │   ├── README.ja.txt                (本ファイル)
          │   ├── customer-diagnostic.cmd
          │   ├── customer-diagnostic.ps1
          │   └── restore-from-defender-quarantine.ps1
          ├── dist\workers\zigma-worker.exe
          └── ZigmaWpfViewer\ZigmaWpfViewer.exe

   注: %PROGRAMFILES% は通常 C:\Program Files です (perMachine x64 インストール · 変更には管理者権限が必要)

────────────────────────────────────────────────────────────────
  §3 起動確認
────────────────────────────────────────────────────────────────

>>> 3.1 Revit 2027 を開いて任意のプロジェクトを新規作成または開く

>>> 3.2 Zigma リボンの確認
   「アドイン」(Add-Ins) タブに切り替え、「Zigma USD」パネルが表示されることを確認:
      • Export to USD
      • Import from USD
      • 3D Viewer
      • About Zigma

>>> 3.3 バージョン情報の確認
   「About Zigma」ダイアログをクリックすると以下が表示されます:
      Version: 5.5.32-release+3A17861E
      Build  : Pre-Beta

────────────────────────────────────────────────────────────────
  §4 ライセンスアクティベーション手順
────────────────────────────────────────────────────────────────

>>> 4.1 マシンコードの取得
   1. About Zigma →「Activate License」
   2. マシンコードのテキストウィンドウに文字列が表示され、自動的にクリップボードへコピーされます
   3. michael.lin@realitymatrixai.com 宛てにメール送信し、ライセンスファイル license.txt を取得

>>> 4.2 ライセンスを貼り付けてアクティベート

   ⚠️ ライセンスは必ず .txt 添付ファイル形式で受け取ること
       Evernote / Word / Notion / OneNote からコピーしないでください (文字が削られます)

   1. license.txt 添付ファイルをデスクトップへダウンロード
   2.「メモ帳」(Notepad) で開く
   3. Ctrl+A で全選択 → Ctrl+C でコピー
   4. About Zigma → License ボックス → Ctrl+V で貼り付け
   5.「Paste & Activate」をクリック
   6. 緑字「License activated successfully!」が表示されれば成功

>>> 4.3 アクティベートに失敗した場合
   §5 トラブルシューティングを参照してください。

────────────────────────────────────────────────────────────────
  §5 トラブルシューティング
────────────────────────────────────────────────────────────────

>>> §5.1 赤字「Defender 隔離」リカバリーダイアログ

   症状:
      About ダイアログに赤字で「重要な Zigma コンポーネントが Microsoft Defender
      により誤検知で隔離されました · リカバリーダイアログを確認してください」
      と表示され、同時に独立ポップアップ「Microsoft Defender Quarantine Detected」
      が出現します。OK 押下後、自動的に tools フォルダが開きます。

   原因:
      Microsoft Defender が Zigma のネイティブコンポーネントに対して
      Trojan:Win32/Wacatac.B!ml の誤検知を発生させ、
      ファイルがディスクから隔離されたため、プラグイン起動時に
      ライセンス処理が失敗しています。

   リカバリー手順 (3 ステップ):

   --- ステップ 1 · 診断ツールの実行 (読み取り専用 · 管理者権限不要) ---

      1.1 (エクスプローラーが既に tools\ フォルダを開いているはずです · 開いていない場合は手動で移動)
            C:\Program Files\Autodesk\Revit\Addins\2027\Zigma\tools\
      1.2「customer-diagnostic.cmd」をダブルクリック
      1.3 約 30 秒待機 · デスクトップに「Zigma-Diagnostic-<コンピュータ名>-<時刻>.txt」が生成されます
      1.4 メモ帳が自動的にレポートを開きます

   --- ステップ 2 · Defender 復元ツールの実行 (管理者権限が必要) ---

      2.1 Revit 2027 を完全に終了 (タスクマネージャーで Revit.exe が無いことを確認)
      2.2 スタートメニュー →「PowerShell」で検索
      2.3「Windows PowerShell」を右クリック →「管理者として実行」
      2.4 UAC プロンプトを承認
      2.5 cd コマンドで tools フォルダへ移動:

             cd "C:\Program Files\Autodesk\Revit\Addins\2027\Zigma\tools"

      2.6 実行:

             .\restore-from-defender-quarantine.ps1

      2.7 結果を確認:
            「DONE · 全部 restore 成功」 → 成功 · ステップ 3 へ
            「FAIL · Restore-MpThreat 全失敗」 → 「手動復元」(ステップ 2.8) へ

      2.8 手動復元 (2.7 が FAIL の場合のみ):
             • Windows + I → プライバシーとセキュリティ → Windows セキュリティ
             • ウイルスと脅威の防止 → 保護の履歴
             • 「Trojan:Win32/Wacatac.B!ml」関連の項目を見つける
             • 該当項目をクリック → 操作 →「許可」(または「復元」)

   --- ステップ 3 · Revit を再起動してライセンスアクティベーションを再試行 ---

      3.1 Revit 2027 を起動
      3.2 Zigma USD タブ → About → Paste & Activate
      3.3 緑字「License activated successfully!」が表示されれば成功

   それでも失敗する場合:
      「Zigma-Diagnostic-*.txt」を以下宛先にメール送付してください:
      michael.lin@realitymatrixai.com (件名形式: [Zigma Pre-Beta v5.5.32] <内容簡述>)

>>> §5.2 橙字「キー長エラー」

   症状:
      About ダイアログに橙字で「アクティベーションコード長エラー · 受信 XXX 文字 ·
      正しくは 780 文字 · .txt 添付ファイルから貼り直してください
      (Evernote / Word / Notion からコピーしないこと)」と表示される。

   原因:
      ライセンス文字列が転送経路上でリッチテキストミドルウェア (Evernote ENML /
      Word 自動整形 / Notion / OneNote 等) により短縮または改変されたためです。

   修復方法:
   1. .txt 添付ファイルから再度ライセンスを取得 (§4.2 参照)
      • Evernote / Word / Notion / OneNote からコピーしないこと
      • 必ず Windows メモ帳 (Notepad) で .txt を開くこと
      • Ctrl+A で全選択 → Ctrl+C でコピー (長さが 780 文字であることを確認)
   2. About Zigma → License ボックス → Ctrl+V → Paste & Activate

   複数回失敗する場合は、ライセンスの再送信を依頼してください:
      michael.lin@realitymatrixai.com
      件名: [Zigma Pre-Beta v5.5.32] ライセンスの再送信依頼 (.txt 添付)

>>> §5.3 Revit にリボンが表示されない

   症状: Revit 2027 の「アドイン」タブに Zigma USD グループが表示されない。

   解決方法:
   1. 以下のファイルが存在することを確認:
         C:\Program Files\Autodesk\Revit\Addins\2027\Zigma.UsdConnector.addin
   2. Revit 通知センター (右上のベルアイコン) でアドイン読み込み失敗メッセージを確認
   3. .NET 10 Desktop Runtime がインストール済みであることを確認 (§1.4 参照)
   4. Revit を完全に終了 (タスクマネージャーで Revit.exe が無いことを確認) し、再起動

>>> §5.4 3D ビューアー起動クラッシュ

   症状: 「3D Viewer」をクリックすると ZigmaWpfViewer.exe が即座にクラッシュする、
        または .NET エラーダイアログが表示される。

   解決方法:
   1. .NET 10 Desktop Runtime がインストール済みであることを確認 (dotnet --list-runtimes)
   2. 未インストールの場合は https://dotnet.microsoft.com/download/dotnet/10.0 からダウンロード
   3. それでもクラッシュする場合は、以下のファイルをサポートまで送付してください:
      • %LOCALAPPDATA%\Zigma\logs\ZigmaSystemLog.log
      • Windows イベントビューアー .NET Runtime エラーのスクリーンショット

────────────────────────────────────────────────────────────────
  §6 アンインストール
────────────────────────────────────────────────────────────────

>>> 6.1 標準アンインストール
   1. 設定 → アプリ → インストールされているアプリ
   2.「Zigma」を検索
   3.「Zigma USD↔Revit Converter」横の ⋯ をクリック →「アンインストール」
   4. UAC → はい → 30〜60 秒待機

>>> 6.2 マルチユーザー残留ファイルのクリーンアップ (該当ユーザーで実行):

      Remove-Item -Recurse -Force "$env:APPDATA\Zigma" -ErrorAction SilentlyContinue
      Remove-Item -Recurse -Force "$env:LOCALAPPDATA\Zigma" -ErrorAction SilentlyContinue
      Remove-Item -Force "$env:USERPROFILE\.config\zigma_config.cfg" -ErrorAction SilentlyContinue

>>> 6.3 Defender 除外設定の削除 (任意):

      Remove-MpPreference -ExclusionPath "C:\Program Files\Autodesk\Revit\Addins\2027"
      Remove-MpPreference -ExclusionPath "C:\Program Files\Autodesk\Revit\Addins\2027"

────────────────────────────────────────────────────────────────
  §7 サポート連絡
────────────────────────────────────────────────────────────────

   Michael Lin (林志錚) · Reality Matrix AI Inc. 創業者 · 実矩科技
      Email   : michael.lin@realitymatrixai.com
      返信時間: 営業日 24 時間以内 (台北時間 UTC+8)

   ⚠️ メール件名形式: [Zigma Pre-Beta v5.5.32] <内容簡述>

   本文に以下を含めてください:
      1. お名前 + 会社名
      2. OS バージョン (winver で確認)
      3. Revit 2027 バージョン番号 (Revit → ヘルプ → バージョン情報)
      4. 問題の説明 + 再現手順
      5. 関連ログ / スクリーンショット (あれば)
      6. (ライセンスアクティベート失敗の場合) デスクトップの Zigma-Diagnostic-*.txt

   ⚠️ 禁止事項:
      • 公開フォーラム (GitHub Issues / Autodesk Forum / Reddit /
        Facebook) への Zigma 関連の投稿
      • ソーシャルメディア (公開 LINE / Discord) での質問
      • MSI またはライセンスファイルを NDA 未締結の第三者へ転送

────────────────────────────────────────────────────────────────
  §8 NDA リマインダー
────────────────────────────────────────────────────────────────

   MSI インストール中に Pre-Beta NDA EULA に同意いただきました · 重要事項:

   1. 製品内部の動作機構、性能データ、バグ、未公開機能 = 機密情報
   2. 保護されたバイナリの逆アセンブル / リバースエンジニアリング / 改変は禁止
   3. 内部テストのスクリーンショット/録画は個人テスト用途のみ · 公開配布禁止
   4. Zigma を基準として競合製品との公開比較を行わないこと
   5. お客様の機密 RVT モデルは送付不可 · 匿名化したサンプル RVT で問題を再現してください

   NDA 有効期限: Zigma の公式正式リリースまで継続して有効 (予定 2026 Q3-Q4)

   違反時の対応 (EULA §0.4 に準拠):
      • Pre-Beta テスト資格の即時失効
      • Reality Matrix AI Inc. は民事/刑事責任の追及権を留保

================================================================
(C) 2026 Reality Matrix AI Inc. · 実矩科技 · All rights reserved.
================================================================
