﻿# ============================================================================
# Zigma Diagnostic Script . License Troubleshooting . Reality Matrix AI Inc.
# ============================================================================
#
# Purpose: When Zigma License activation fails, auto-collect diagnostic info
#          and output to Desktop .txt . Email it back as attachment.
#
# Two common activation failure scenarios:
#   1. License string truncated during paste (from Evernote / Word / Notion)
#   2. Microsoft Defender mistakenly quarantined Zigma DLL (Wacatac.B!ml)
#
# Diagnostic items:
#   A. Defender exclusion paths (whether Zigma path is added)
#   B. Defender quarantine history (whether Zigma DLL was quarantined)
#   C. Zigma Plugin component file status (whether on disk)
#   D. Revit .addin manifest registration status
#   E. Zigma system log (last 30 lines)
#   F. License file status (length check . verify transmission integrity)
#
# Output:
#   Desktop/Documents . Zigma-Diagnostic-<computer>-<yyyyMMdd-HHmmss>.txt
#   Notepad auto-opens after completion
#
# Auto-locale: zh-TW / en / ja based on system UI culture (fallback en)
#
# Safety:
#   Pure read-only . does not modify system settings / files / registry
#   Does NOT collect personal data (email / password) . only Zigma paths and
#   Defender event IDs . Does NOT upload anything . user decides whether to
#   email the .txt back.
#
# Zigma USD Connector v5.5.41 Pre-Beta . 2026-05-28 +0800 . Reality Matrix AI Inc.
# ============================================================================

$ErrorActionPreference = 'Continue'

# === i18n locale detection ===
$systemLang = [System.Globalization.CultureInfo]::CurrentUICulture.Name
$lang = if ($systemLang -match '^zh') { 'zh' }
        elseif ($systemLang -match '^ja') { 'ja' }
        else { 'en' }

function T {
    param([string]$zh, [string]$en, [string]$ja)
    switch ($lang) {
        'zh' { return $zh }
        'ja' { return $ja }
        default { return $en }
    }
}

# === Step 0 . Output file location ===
$timestamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$computerName = $env:COMPUTERNAME
# Desktop first . fallback Documents
$desktop = [Environment]::GetFolderPath('Desktop')
$documents = [Environment]::GetFolderPath('MyDocuments')
$outputDir = if (Test-Path $desktop) { $desktop } else { $documents }
$outputFile = Join-Path $outputDir "Zigma-Diagnostic-$computerName-$timestamp.txt"

# Output buffer
$lines = [System.Collections.ArrayList]::new()

function Add-Line {
    param([string]$text)
    [void]$lines.Add($text)
    Write-Host $text
}

function Add-Section {
    param([string]$title)
    Add-Line ""
    Add-Line "=========================================================="
    Add-Line "  $title"
    Add-Line "=========================================================="
}

# === Header ===
Add-Line "============================================================"
Add-Line (T "  Zigma 診斷報告 · Reality Matrix AI Inc." `
            "  Zigma Diagnostic Report · Reality Matrix AI Inc." `
            "  Zigma 診断レポート · Reality Matrix AI Inc.")
Add-Line "============================================================"
Add-Line ((T "產出時間 : " "Generated : " "生成時刻 : ") + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss zzz'))
Add-Line ((T "電腦名稱 : " "Computer  : " "コンピューター名 : ") + $computerName)
Add-Line ("Windows  : " + (Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue).Caption)
Add-Line ((T "使用者   : " "User      : " "ユーザー : ") + $env:USERNAME)
Add-Line ((T "語系     : " "Locale    : " "ロケール : ") + $systemLang + " (lang=" + $lang + ")")
Add-Line "============================================================"

# === A. Defender exclusion paths ===
Add-Section (T "A. Microsoft Defender 排除路徑 (Exclusion Paths)" `
               "A. Microsoft Defender Exclusion Paths" `
               "A. Microsoft Defender 除外パス (Exclusion Paths)")
Add-Line (T "用途: 確認 Zigma 路徑是否已加入 Defender 排除清單 (避免誤判隔離)" `
            "Purpose: Verify Zigma paths are added to Defender exclusion list (prevent mistaken quarantine)" `
            "用途: Zigma パスが Defender 除外リストに追加されているか確認 (誤検知による隔離の防止)")
Add-Line ""
try {
    $pref = Get-MpPreference -ErrorAction Stop
    if ($pref.ExclusionPath -and $pref.ExclusionPath.Count -gt 0) {
        Add-Line ((T "目前排除路徑 (" "Current exclusion paths (" "現在の除外パス (") + $pref.ExclusionPath.Count + (T " 條):" " entries):" " 件):"))
        foreach ($p in $pref.ExclusionPath) {
            $isZigma = $p -match 'Zigma|Autodesk'
            $marker = if ($isZigma) { ' [Zigma]' } else { '' }
            Add-Line "  - $p$marker"
        }
    } else {
        Add-Line (T "[WARN]  排除清單為空 · Defender 未排除任何路徑" `
                    "[WARN]  Exclusion list is empty · Defender excludes no paths" `
                    "[WARN]  除外リストが空 · Defender は何も除外していません")
    }
} catch {
    Add-Line ((T "[WARN]  無法讀取 Defender 設定: " `
                 "[WARN]  Cannot read Defender settings: " `
                 "[WARN]  Defender 設定を読み取れません: ") + $_.Exception.Message)
    Add-Line (T "   可能原因: Defender 服務未執行 OR 企業 GPO 限制" `
                "   Possible cause: Defender service not running OR enterprise GPO restriction" `
                "   考えられる原因: Defender サービス停止 OR 企業 GPO 制限")
}

# === B. Defender quarantine history ===
Add-Section (T "B. Microsoft Defender 隔離歷程 (最近 30 日 · Wacatac etc)" `
               "B. Microsoft Defender Quarantine History (last 30 days · Wacatac etc)" `
               "B. Microsoft Defender 隔離履歴 (最近 30 日 · Wacatac 等)")
Add-Line (T "用途: 確認 Defender 是否曾誤判隔離 Zigma DLL (Wacatac.B!ml)" `
            "Purpose: Verify whether Defender mistakenly quarantined Zigma DLL (Wacatac.B!ml)" `
            "用途: Defender が Zigma DLL を誤検知で隔離したか確認 (Wacatac.B!ml)")
Add-Line ""
try {
    $events = Get-WinEvent -LogName "Microsoft-Windows-Windows Defender/Operational" `
        -MaxEvents 1000 -ErrorAction SilentlyContinue |
        Where-Object {
            $_.Id -in 1006, 1007, 1015, 1116, 1117, 5007 -and
            $_.TimeCreated -gt (Get-Date).AddDays(-30)
        } |
        Select-Object -First 30
    if ($events -and $events.Count -gt 0) {
        Add-Line ((T "找到 " "Found " "検出 ") + $events.Count + (T " 個相關 events (Event ID 1116/1117 = DETECT/QUARANTINE):" `
                                                                   " related events (Event ID 1116/1117 = DETECT/QUARANTINE):" `
                                                                   " 件の関連イベント (Event ID 1116/1117 = DETECT/QUARANTINE):"))
        Add-Line ""
        foreach ($e in $events) {
            $firstLine = ($e.Message -split "`n")[0].Trim()
            Add-Line "  [$($e.TimeCreated.ToString('yyyy-MM-dd HH:mm:ss'))] ID=$($e.Id) Level=$($e.LevelDisplayName)"
            Add-Line "    $firstLine"
        }
    } else {
        Add-Line (T "[OK] 最近 30 日無 Defender 相關 events (沒有隔離記錄)" `
                    "[OK] No Defender events in the last 30 days (no quarantine record)" `
                    "[OK] 最近 30 日間 Defender 関連イベントなし (隔離記録なし)")
    }
} catch {
    Add-Line ((T "[WARN]  無法讀取 Defender event log: " `
                 "[WARN]  Cannot read Defender event log: " `
                 "[WARN]  Defender イベントログを読み取れません: ") + $_.Exception.Message)
}

# === C. Zigma Plugin DLL file status ===
Add-Section (T "C. Zigma Plugin 元件檔案狀態" `
               "C. Zigma Plugin Component File Status" `
               "C. Zigma Plugin コンポーネントファイル状態")
Add-Line (T "用途: 確認 Plugin DLL 是否仍存在於 disk (排除 Defender 隔離後 file gone)" `
            "Purpose: Verify Plugin DLL still exists on disk (rule out post-quarantine file removal)" `
            "用途: Plugin DLL がディスクに存在するか確認 (Defender 隔離後のファイル消失を除外)")
Add-Line ""
$paths = @(
    # v5.5.23+ vendor subfolder paths (PRIMARY · per WiX ProgramFiles64Folder + Zigma\ vendor dir)
    "C:\Program Files\Autodesk\Revit\Addins\2027\Zigma\ZigmaRenderUtil.dll",
    "C:\Program Files\Autodesk\Revit\Addins\2027\Zigma\Zigma.UsdConnector.dll",
    "C:\Program Files\Autodesk\Revit\Addins\2027\Zigma\dist\workers\zigma-worker.exe",
    "C:\Program Files\Autodesk\Revit\Addins\2027\Zigma\dist\workers\MachineKeyGenerator.exe",
    # v5.5.22 legacy paths (flat layout · fallback for testers who haven't upgraded)
    "C:\Program Files\Autodesk\Revit\Addins\2027\ZigmaRenderUtil.dll",
    "C:\Program Files\Autodesk\Revit\Addins\2027\Zigma.UsdConnector.dll",
    "C:\Program Files\Autodesk\Revit\Addins\2027\dist\workers\zigma-worker.exe",
    # perUser legacy paths (some testers may have older perUser install)
    "$env:APPDATA\Autodesk\Revit\Addins\2027\Zigma\ZigmaRenderUtil.dll",
    "$env:APPDATA\Autodesk\Revit\Addins\2027\Zigma\Zigma.UsdConnector.dll"
)
foreach ($p in $paths) {
    if (Test-Path $p) {
        try {
            $info = Get-Item $p -ErrorAction Stop
            $sha = (Get-FileHash $p -Algorithm SHA256 -ErrorAction Stop).Hash.Substring(0,8)
            Add-Line "  [OK] EXIST: $p"
            Add-Line ((T "        大小=" "        Size=" "        サイズ=") + $info.Length + " bytes · SHA8=$sha · " + (T "修改時間=" "Modified=" "更新日時=") + $info.LastWriteTime.ToString('yyyy-MM-dd HH:mm:ss'))
        } catch {
            Add-Line (T "  [WARN]  存在但無法讀取: " `
                        "  [WARN]  FOUND but no read access: " `
                        "  [WARN]  存在しますが読み取り不可: ") + $p
        }
    } else {
        Add-Line "  [X] MISSING: $p"
    }
}

# === D. .addin registration ===
Add-Section (T "D. Revit .addin Manifest 註冊狀態" `
               "D. Revit .addin Manifest Registration Status" `
               "D. Revit .addin マニフェスト登録状態")
Add-Line (T "用途: 確認 Revit 是否認得 Zigma plugin (3 個可能註冊位置)" `
            "Purpose: Verify Revit recognizes Zigma plugin (3 possible registration locations)" `
            "用途: Revit が Zigma plugin を認識しているか確認 (3 つの登録場所)")
Add-Line ""
$addins = @(
    # Main install path (perMachine x64)
    "C:\Program Files\Autodesk\Revit\Addins\2027\Zigma.UsdConnector.addin",
    # perUser legacy fallback
    "$env:APPDATA\Autodesk\Revit\Addins\2027\Zigma.UsdConnector.addin"
)
foreach ($a in $addins) {
    if (Test-Path $a) {
        Add-Line "  [OK] EXIST: $a"
    } else {
        Add-Line "  [X] MISSING: $a"
    }
}

# === E. Zigma system log (last 30 lines) ===
Add-Section (T "E. Zigma 系統日誌 (最近 30 行 · License 啟動細節)" `
               "E. Zigma System Log (last 30 lines · License activation details)" `
               "E. Zigma システムログ (最近 30 行 · License アクティベーション詳細)")
Add-Line (T "用途: 查看 Plugin 啟動時的詳細狀態 · 含 License 啟動失敗原因 (若有)" `
            "Purpose: View detailed Plugin startup status · including License activation failure cause (if any)" `
            "用途: Plugin 起動時の詳細状態を確認 · License アクティベーション失敗の原因を含む (該当する場合)")
Add-Line ""
$log = "$env:LOCALAPPDATA\Zigma\logs\ZigmaSystemLog.log"
if (Test-Path $log) {
    Add-Line "Log file: $log"
    Add-Line ""
    try {
        $logLines = Get-Content $log -Tail 30 -Encoding UTF8 -ErrorAction Stop
        foreach ($l in $logLines) { Add-Line "  $l" }
    } catch {
        Add-Line ((T "[WARN]  無法讀取 log: " `
                     "[WARN]  Cannot read log: " `
                     "[WARN]  ログを読み取れません: ") + $_.Exception.Message)
    }
} else {
    Add-Line ("[X] MISSING: $log  " + (T "(Zigma 從未啟動過 OR log 已被清除)" `
                                          "(Zigma never started OR log was cleared)" `
                                          "(Zigma が起動したことがない OR ログが削除されました)"))
}

# === F. License v4 file status ===
Add-Section (T "F. License v4 檔案 (paste-activate 後寫入)" `
               "F. License v4 File (written after paste-activate)" `
               "F. License v4 ファイル (paste-activate 後に書き込み)")
Add-Line (T "用途: 確認 license-v4.b64 長度是否為 780 chars (V4 標準 · transmission corruption check)" `
            "Purpose: Verify license-v4.b64 length is 780 chars (V4 standard · transmission corruption check)" `
            "用途: license-v4.b64 の長さが 780 chars か確認 (V4 標準 · 転送破損チェック)")
Add-Line ""
$v4 = "$env:LOCALAPPDATA\Zigma\license-v4.b64"
if (Test-Path $v4) {
    try {
        $rawContent = Get-Content $v4 -Raw -ErrorAction Stop
        $trimmed = $rawContent.Trim()
        Add-Line "[OK] EXIST: $v4"
        Add-Line ((T "  原始長度    : " "  Raw length    : " "  生の長さ    : ") + $rawContent.Length + " chars")
        Add-Line ((T "  Trim 後長度 : " "  Trimmed length: " "  Trim 後の長さ: ") + $trimmed.Length + (T " chars  (期望 780 chars for V4 · 522 chars for V1)" `
                                                                                                          " chars  (expected 780 chars for V4 · 522 chars for V1)" `
                                                                                                          " chars  (V4 標準 780 chars · V1 は 522 chars)"))
        if ($trimmed.Length -ge 6) {
            Add-Line ((T "  前 6 字       : " "  First 6 chars : " "  先頭 6 文字   : ") + $trimmed.Substring(0, 6))
        }
        if ($trimmed.Length -eq 780) {
            Add-Line (T "  [OK] 長度正確 (V4 standard 780 chars) · transmission 無砍字" `
                        "  [OK] Length correct (V4 standard 780 chars) · no transmission truncation" `
                        "  [OK] 長さ正常 (V4 標準 780 chars) · 転送切り捨てなし")
        } elseif ($trimmed.Length -ge 518 -and $trimmed.Length -le 524) {
            Add-Line (T "  [WARN]  V1 legacy 長度 (518-524 chars) · 為舊版 license · 建議重新請求 V4" `
                        "  [WARN]  V1 legacy length (518-524 chars) · old license version · please request V4" `
                        "  [WARN]  V1 レガシー長 (518-524 chars) · 旧バージョン license · V4 を再リクエストしてください")
        } else {
            Add-Line ((T "  [WARN] [WARN]  長度異常 (" "  [WARN] [WARN]  Length abnormal (" "  [WARN] [WARN]  長さ異常 (") + $trimmed.Length + (T " chars) · 高度可能是 Evernote / Word / Notion 砍字" `
                                                                                                                                                       " chars) · likely truncated by Evernote / Word / Notion" `
                                                                                                                                                       " chars) · Evernote / Word / Notion による切り捨ての可能性大"))
            Add-Line (T "         請從 .txt 附件複製 license (不要從 Evernote / Word / Notion)" `
                        "         Please copy license from .txt attachment (NOT from Evernote / Word / Notion)" `
                        "         license は .txt 添付からコピーしてください (Evernote / Word / Notion からはダメ)")
        }
    } catch {
        Add-Line ((T "[WARN]  無法讀取 license-v4.b64: " `
                     "[WARN]  Cannot read license-v4.b64: " `
                     "[WARN]  license-v4.b64 を読み取れません: ") + $_.Exception.Message)
    }
} else {
    Add-Line ("[X] MISSING: $v4  " + (T "(Plugin paste-activate 後應自動產生此檔)" `
                                         "(should auto-generate after Plugin paste-activate)" `
                                         "(Plugin paste-activate 後に自動生成されるはず)"))
    Add-Line (T "   可能原因: 從未 paste OR paste 後 activate 失敗 OR Defender 阻擋寫入" `
                "   Possible cause: never pasted OR activation failed after paste OR Defender blocked write" `
                "   考えられる原因: 一度も paste していない OR paste 後 activate 失敗 OR Defender が書き込みをブロック")
}

# === Footer ===
Add-Section (T "診斷完成 · 請將本檔案 email 寄回" `
               "Diagnostic complete · please email this file back" `
               "診断完了 · このファイルを Email で返送してください")
Add-Line ""
Add-Line (T "[EMAIL] 寄回 email: michael.lin@realitymatrixai.com" `
            "[EMAIL] Send to    : michael.lin@realitymatrixai.com" `
            "[EMAIL] 返送先     : michael.lin@realitymatrixai.com")
Add-Line ((T "[FILE]  檔案位置 : " "[FILE]  File location: " "[FILE]  ファイル場所: ") + $outputFile)
Add-Line ""
Add-Line (T "謝謝您的協助 · 我們會盡快回覆解決方案" `
            "Thank you for your help · we will reply with a solution ASAP" `
            "ご協力ありがとうございます · 早急に解決策をご返信いたします")
Add-Line ""

# === Save to file ===
try {
    $lines | Out-File -FilePath $outputFile -Encoding UTF8 -Force
    Write-Host ""
    Write-Host ((T "[OK] 診斷報告已儲存: " "[OK] Diagnostic report saved: " "[OK] 診断レポート保存先: ") + $outputFile) -ForegroundColor Green
    Write-Host ""
    # Auto-open Notepad to show result
    Start-Process notepad.exe -ArgumentList "`"$outputFile`""
    exit 0
} catch {
    Write-Host ""
    Write-Host ((T "[X] 儲存失敗: " "[X] Save failed: " "[X] 保存失敗: ") + $_.Exception.Message) -ForegroundColor Red
    Write-Host (T "  請手動將上方顯示的內容複製 · 寄回 michael.lin@realitymatrixai.com" `
                  "  Please manually copy the content shown above · email back to michael.lin@realitymatrixai.com" `
                  "  上記の内容を手動でコピーし · michael.lin@realitymatrixai.com まで送信してください")
    exit 1
}
