﻿# ============================================================================
# Zigma Converter . Restore from Defender Quarantine Helper
# ============================================================================
#
# Purpose: When Microsoft Defender mistakenly quarantines Zigma components
#          (Trojan:Win32/Wacatac.B!ml) . auto-query quarantine area . restore
#          files . and re-add Defender exclusions to prevent re-quarantine.
#
# Trigger scenarios:
#   - Defender real-time scan mistakenly detects Wacatac.B!ml signature
#   - Event 1116 DETECT -> Event 1117 QUARANTINE
#   - DLL removed from disk -> Plugin startup License fails
#   - About Dialog shows red text "Important Zigma DLL was mistakenly
#     quarantined by Microsoft Defender..."
#
# Three layers of protection:
#   Layer 1 . MSI installer auto-adds Defender exclusion paths (~90% prevention)
#   Layer 2 . About Dialog UI detects and guides user to run recovery
#   Layer 3 . This script . auto-repair tool after quarantine has occurred
#
# Usage:
#   1. Right-click PowerShell . "Run as Administrator" (required . Defender
#      cmdlets require admin)
#   2. cd to script directory
#   3. .\restore-from-defender-quarantine.ps1
#   4. Check result . EXIT_CODE = 0 means success
#   5. Restart Revit and retry License activation
#
# Auto-locale: zh-TW / en / ja based on system UI culture (fallback en)
#
# Exit codes:
#   0  . success (restored 1+ files OR no quarantine found and exclusions added)
#   1  . not running as admin (re-launch with elevation)
#   2  . Defender cmdlets unavailable (Windows too old OR GPO disabled)
#   3  . quarantine items found but Restore-MpThreat failed
#   4  . partial success (some restore OK . some failed)
#
# Zigma USD Connector v5.5.41 Pre-Beta . 2026-05-28 +0800 . Reality Matrix AI Inc.
# ============================================================================

[CmdletBinding()]
param(
    [switch]$Verify   # -Verify mode: query status only . do not restore (test mode)
)

$ErrorActionPreference = 'Continue'

# === i18n locale detection ===
$systemLang = [System.Globalization.CultureInfo]::CurrentUICulture.Name
$lang = if ($systemLang -match '^zh') { 'zh' }
        elseif ($systemLang -match '^ja') { 'ja' }
        else { 'en' }

function T {
    param([string]$zh, [string]$en, [string]$ja)
    switch ($lang) {
        'zh' { return $zh }
        'ja' { return $ja }
        default { return $en }
    }
}

function Write-Step([string]$msg, [string]$color = 'Cyan') {
    Write-Host "[$([DateTime]::Now.ToString('HH:mm:ss'))] $msg" -ForegroundColor $color
}

# === Step 1 . Admin elevation check ===
$identity = [System.Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object System.Security.Principal.WindowsPrincipal($identity)
$isAdmin = $principal.IsInRole([System.Security.Principal.WindowsBuiltInRole]::Administrator)

if (-not $isAdmin -and -not $Verify) {
    # v5.5.41: -Verify mode is a read-only self-test · admin not required ·
    #   only RESTORE mode (no -Verify) needs admin to call Restore-MpThreat / MpCmdRun.exe -Restore
    Write-Step (T "ERROR: 此 script 需要 admin 權限執行 (RESTORE mode)" `
                  "ERROR: This script requires admin privileges (RESTORE mode)" `
                  "ERROR: このスクリプトには管理者権限が必要です (RESTORE モード)") 'Red'
    Write-Step (T "  請右鍵 PowerShell -> 「以系統管理員身分執行」 -> 再跑此 script" `
                  "  Right-click PowerShell -> 'Run as Administrator' -> re-run this script" `
                  "  PowerShell を右クリック -> 「管理者として実行」 -> 再度このスクリプトを実行") 'Yellow'
    Write-Step (T "  (或加 -Verify 參數做唯讀自我檢測 · 不需 admin)" `
                  "  (Or add -Verify parameter for read-only self-test · no admin needed)" `
                  "  (または -Verify パラメータを追加して読み取り専用セルフテスト · admin 不要)") 'Yellow'
    exit 1
}

$modeLabel = if ($Verify) {
    T 'VERIFY (測試模式 / 不實際還原)' 'VERIFY (test mode / no actual restore)' 'VERIFY (テストモード / 実際の復元なし)'
} else {
    T 'RESTORE' 'RESTORE' 'RESTORE'
}
Write-Step ((T "Zigma Defender Quarantine Recovery · Admin OK · Mode=" `
               "Zigma Defender Quarantine Recovery · Admin OK · Mode=" `
               "Zigma Defender 隔離復元 · 管理者 OK · Mode=") + $modeLabel) 'Green'

# === Step 1.5 . Environment diagnostic + Import-Module Defender + MpCmdRun locate ===
# v5.5.41 · trial user P1 feedback . one-shot env dump for root-cause attribution
Write-Step ("[Diag] PSVersion=" + $PSVersionTable.PSVersion + " . OSVersion=" + [System.Environment]::OSVersion.Version) 'DarkGray'
$defenderModule = $null
try { $defenderModule = Get-Module -ListAvailable -Name Defender, ConfigDefender -ErrorAction SilentlyContinue } catch { }
$moduleAvailable = (($defenderModule | Measure-Object).Count -gt 0)
Write-Step ("[Diag] Defender PS Module Available=" + $moduleAvailable) 'DarkGray'
if ($moduleAvailable) {
    try {
        Import-Module $defenderModule[0].Name -Force -ErrorAction Stop
        Write-Step ("[Diag] Import-Module " + $defenderModule[0].Name + " OK") 'DarkGray'
    } catch {
        Write-Step ("[Diag] Import-Module FAIL: " + $_.Exception.Message) 'DarkGray'
    }
}

# Locate MpCmdRun.exe . always-available since Win7 SP1 . Layer 2 fallback CLI
$mpCmdRun = "$env:ProgramFiles\Windows Defender\MpCmdRun.exe"
if (-not (Test-Path $mpCmdRun)) {
    $platformDir = "$env:ProgramData\Microsoft\Windows Defender\Platform"
    if (Test-Path $platformDir) {
        $latestPlatform = Get-ChildItem $platformDir -Directory -ErrorAction SilentlyContinue |
            Sort-Object Name -Descending | Select-Object -First 1
        if ($latestPlatform) {
            $candidate = Join-Path $latestPlatform.FullName 'MpCmdRun.exe'
            if (Test-Path $candidate) { $mpCmdRun = $candidate }
        }
    }
}
$mpCmdRunAvailable = (Test-Path $mpCmdRun)
Write-Step ("[Diag] MpCmdRun.exe=" + $mpCmdRun + " . available=" + $mpCmdRunAvailable) 'DarkGray'
$restoreMpThreatCmdletAvailable = ((Get-Command Restore-MpThreat -ErrorAction SilentlyContinue) -ne $null)
$addMpPreferenceCmdletAvailable = ((Get-Command Add-MpPreference -ErrorAction SilentlyContinue) -ne $null)
Write-Step ("[Diag] Restore-MpThreat=" + $restoreMpThreatCmdletAvailable + " . Add-MpPreference=" + $addMpPreferenceCmdletAvailable) 'DarkGray'
Write-Host ""

# === Step 2 . Defender cmdlets availability check (v5.5.41 fix · graceful degrade) ===
# CRITICAL cmdlets (must have): Get-MpPreference / Add-MpPreference for exclusion paths
# OPTIONAL cmdlets: Get-MpThreat / Get-MpThreatDetection / Restore-MpThreat (for quarantine restore)
# If optional missing, script still useful for exclusion re-add (most common use case)
$criticalCmdlets = @('Get-MpPreference', 'Add-MpPreference')
$optionalCmdlets = @('Get-MpThreat', 'Get-MpThreatDetection', 'Restore-MpThreat')
$missingCritical = @()
$missingOptional = @()
foreach ($c in $criticalCmdlets) {
    if (-not (Get-Command $c -ErrorAction SilentlyContinue)) { $missingCritical += $c }
}
foreach ($c in $optionalCmdlets) {
    if (-not (Get-Command $c -ErrorAction SilentlyContinue)) { $missingOptional += $c }
}
if ($missingCritical.Count -gt 0) {
    Write-Step ((T "ERROR: 必要 Defender cmdlet 不可用: " `
                   "ERROR: Critical Defender cmdlets unavailable: " `
                   "ERROR: 必要な Defender cmdlet が使用不可: ") + ($missingCritical -join ', ')) 'Red'
    Write-Step (T "  FACT 根因: Defender PS module 未載入 OR Windows SKU 精簡安裝 (Home N/KN) OR 企業 GPO 限制 Defender" `
                  "  FACT root cause: Defender PS module not loaded OR Windows SKU stripped (Home N/KN) OR enterprise GPO restriction" `
                  "  FACT 根本原因: Defender PS module 未ロード OR Windows SKU 簡易版 (Home N/KN) OR 企業 GPO 制限") 'Yellow'
    Write-Step (T "  請聯絡支援: michael.lin@realitymatrixai.com" `
                  "  Please contact support: michael.lin@realitymatrixai.com" `
                  "  サポートにご連絡ください: michael.lin@realitymatrixai.com") 'Yellow'
    exit 2
}
if ($missingOptional.Count -gt 0) {
    Write-Step ((T "WARN: 部分 Defender cmdlet 不可用 (quarantine restore 跳過): " `
                   "WARN: Some Defender cmdlets unavailable (quarantine restore will be skipped): " `
                   "WARN: 一部 Defender cmdlet 使用不可 (quarantine restore はスキップ): ") + ($missingOptional -join ', ')) 'Yellow'
    Write-Step (T "  → 仍會執行 exclusion path re-add (主要功能 · 預防再隔離)" `
                  "  → Will still re-add exclusion paths (primary function · prevent re-quarantine)" `
                  "  → 除外パスの再追加は実行 (主機能 · 再隔離防止)") 'Yellow'
}
$quarantineRestoreAvailable = ($missingOptional -notcontains 'Restore-MpThreat' -and $missingOptional -notcontains 'Get-MpThreat')

# === Step 3 . Query Defender detected threats (incl. quarantine) ===
$allThreats = @()
$detections = @()
if ($quarantineRestoreAvailable) {
    Write-Step (T "查詢 Defender 威脅紀錄 (含隔離區)..." `
                  "Querying Defender threat records (incl. quarantine area)..." `
                  "Defender 脅威記録を検索中 (隔離エリアを含む)...")
    try { $allThreats = @(Get-MpThreat -ErrorAction SilentlyContinue) } catch { }
    try { $detections = @(Get-MpThreatDetection -ErrorAction SilentlyContinue) } catch { $detections = @() }
} else {
    Write-Step (T "Quarantine 查詢已跳過 (cmdlet 不可用) · 直接進入 exclusion path 重設步驟" `
                  "Quarantine query skipped (cmdlet unavailable) · proceeding to exclusion path re-add" `
                  "Quarantine 検索をスキップ (cmdlet 使用不可) · 除外パス再追加へ") 'Yellow'
}

# Zigma binaries (commonly mistakenly flagged by Wacatac)
$zigmaBinaries = @(
    'ZigmaRenderUtil.dll',
    'zigma-worker.exe',
    'MachineKeyGenerator.exe',
    'zigma-usd-mesh-cli.exe'
)

# Match threats whose Resources path contains Zigma binary names
$zigmaThreats = $allThreats | Where-Object {
    $res = $_.Resources -join '|'
    $matched = $false
    foreach ($bin in $zigmaBinaries) {
        if ($res -match [regex]::Escape($bin)) { $matched = $true; break }
    }
    $matched
}

Write-Step ((T "Defender 總 threats: " "Defender total threats: " "Defender 全脅威: ") + $allThreats.Count + (T " · Zigma 相關: " " · Zigma related: " " · Zigma 関連: ") + $zigmaThreats.Count + (T " · Detection 紀錄: " " · Detection records: " " · Detection 記録: ") + $detections.Count)

if ($zigmaThreats.Count -eq 0) {
    Write-Step (T "OK · 無 Zigma 相關 quarantine 項目 (Defender 沒誤判 OR 已 restore)" `
                  "OK · No Zigma related quarantine items (not mistakenly flagged OR already restored)" `
                  "OK · Zigma 関連の隔離項目なし (誤検知なし OR 既に復元済み)") 'Green'
} else {
    Write-Step ((T "發現 " "Found " "検出 ") + $zigmaThreats.Count + (T " 個 Zigma 相關 quarantine 項目:" `
                                                                          " Zigma related quarantine items:" `
                                                                          " 件の Zigma 関連隔離項目:")) 'Yellow'
    foreach ($t in $zigmaThreats) {
        Write-Host "  ThreatID: $($t.ThreatID) · Name: $($t.ThreatName) · Resources: $($t.Resources -join '; ')" -ForegroundColor Gray
    }
}

# === Step 4 . Restore (unless -Verify mode) . 3-layer fallback chain (v5.5.41) ===
$restoreOk = 0
$restoreFail = 0
$mpCmdRunRestoreSucceeded = $false
if ($Verify) {
    Write-Step (T "VERIFY mode · 跳過 restore action (測試模式 · 不實際還原)" `
                  "VERIFY mode · skip restore action (test mode · no actual restore)" `
                  "VERIFY mode · restore action をスキップ (テストモード · 実際の復元なし)") 'Yellow'
} else {
    # Layer 1 . PowerShell Restore-MpThreat (preferred path . per-ThreatID granular)
    foreach ($t in $zigmaThreats) {
        Write-Step ((T "Layer1 Restore ThreatID " "Layer1 Restore ThreatID " "Layer1 復元 ThreatID ") + $t.ThreatID + " (" + $t.ThreatName + ")...") 'Cyan'
        try {
            Restore-MpThreat -ThreatID $t.ThreatID -ErrorAction Stop
            $restoreOk++
            Write-Step (T "  OK · 已 restore" `
                          "  OK · restored" `
                          "  OK · 復元完了") 'Green'
        } catch {
            $restoreFail++
            Write-Step ((T "  FAIL · " "  FAIL · " "  FAIL · ") + $_.Exception.Message) 'Red'
        }
    }

    # Layer 2 . MpCmdRun.exe CLI fallback . when PS cmdlet unavailable
    # FACT . MpCmdRun.exe is always-available since Win7 SP1 . Microsoft official tool
    if ((-not $quarantineRestoreAvailable) -and $mpCmdRunAvailable) {
        Write-Step (T "Layer2 fallback · 嘗試 MpCmdRun.exe -Restore -All (PS cmdlet 不可用)" `
                      "Layer2 fallback · trying MpCmdRun.exe -Restore -All (PS cmdlet unavailable)" `
                      "Layer2 fallback · MpCmdRun.exe -Restore -All を試行 (PS cmdlet 使用不可)") 'Cyan'
        try {
            $listOutput = & $mpCmdRun -Restore -ListAll 2>&1
            $listText = ($listOutput | Out-String).Trim()
            if ($listText) { Write-Host ("  [List] " + $listText) -ForegroundColor DarkGray }
            $restoreOutput = & $mpCmdRun -Restore -All 2>&1
            $restoreText = ($restoreOutput | Out-String).Trim()
            if ($restoreText) { Write-Host ("  [Restore-All] " + $restoreText) -ForegroundColor DarkGray }
            if ($LASTEXITCODE -eq 0) {
                $mpCmdRunRestoreSucceeded = $true
                $restoreOk = [Math]::Max($restoreOk, 1)
                Write-Step (T "  OK · MpCmdRun.exe Restore-All 成功 (exit=0)" `
                              "  OK · MpCmdRun.exe Restore-All success (exit=0)" `
                              "  OK · MpCmdRun.exe Restore-All 成功 (exit=0)") 'Green'
            } else {
                Write-Step (T ("  WARN · MpCmdRun.exe exit code=" + $LASTEXITCODE + " · 可能無 quarantine 項目") `
                              ("  WARN · MpCmdRun.exe exit code=" + $LASTEXITCODE + " · may have no quarantine items") `
                              ("  WARN · MpCmdRun.exe 終了コード=" + $LASTEXITCODE + " · quarantine 項目なしの可能性")) 'Yellow'
            }
        } catch {
            Write-Step ((T "  FAIL MpCmdRun.exe · " "  FAIL MpCmdRun.exe · " "  FAIL MpCmdRun.exe · ") + $_.Exception.Message) 'Red'
        }
    }
}

# === Step 5 . Re-add Defender exclusion paths (prevent re-quarantine) ===
$exclusionPaths = @(
    'C:\Program Files\Autodesk\Revit\Addins\2027',
    'C:\Program Files\Autodesk\Revit\Addins\2027\Zigma',
    'C:\Program Files\Autodesk\Revit\Addins\2027\Zigma\dist',
    'C:\Program Files\Autodesk\Revit\Addins\2027\Zigma\dist\workers',
    'C:\Program Files\Reality Matrix AI\Zigma Viewer'
)

if (-not $Verify) {
    Write-Step (T "Re-add Defender exclusion paths (idempotent)..." `
                  "Re-add Defender exclusion paths (idempotent)..." `
                  "Defender 除外パスを再追加 (idempotent)...")
    foreach ($p in $exclusionPaths) {
        try {
            Add-MpPreference -ExclusionPath $p -ErrorAction SilentlyContinue
            Write-Host "  + $p" -ForegroundColor DarkGray
        } catch { }
    }
    Write-Step (T "OK · exclusion paths 已 re-add" `
                  "OK · exclusion paths re-added" `
                  "OK · 除外パスを再追加しました") 'Green'
}

# === Step 6 . Report + exit ===
Write-Host ""
Write-Step (T "===== 結果摘要 =====" `
              "===== Result Summary =====" `
              "===== 結果サマリー =====") 'Cyan'
Write-Host ((T "  Zigma quarantine 項目: " "  Zigma quarantine items: " "  Zigma 隔離項目: ") + $zigmaThreats.Count)
if (-not $Verify) {
    Write-Host ((T "  Restore 成功: " "  Restore OK: " "  復元成功: ") + $restoreOk + (T " · 失敗: " " · failed: " " · 失敗: ") + $restoreFail)
    Write-Host ((T "  Exclusion paths 已 re-add: " "  Exclusion paths re-added: " "  除外パス再追加: ") + $exclusionPaths.Count + (T " 條" " entries" " 件"))
}
Write-Host ""

# Whether quarantine check was actually performed (Layer 1 OR Layer 2)
$autoCheckPerformed = $quarantineRestoreAvailable -or $mpCmdRunRestoreSucceeded -or $mpCmdRunAvailable

if ($Verify) {
    Write-Step (T "VERIFY DONE · 若要 restore · 不加 -Verify 參數重跑此 script" `
                  "VERIFY DONE · to restore · re-run this script WITHOUT -Verify parameter" `
                  "VERIFY DONE · 復元するには · -Verify パラメータなしで再実行してください") 'Yellow'
    exit 0
} elseif ($zigmaThreats.Count -eq 0 -and $quarantineRestoreAvailable) {
    Write-Step (T "DONE · 系統乾淨 (PS cmdlet 已查無 quarantine) · 可重啟 Revit 試 License paste-activate" `
                  "DONE · System clean (PS cmdlet found no quarantine) · restart Revit and try License paste-activate" `
                  "DONE · システム正常 (PS cmdlet で quarantine なし確認) · Revit を再起動し License paste-activate を試してください") 'Green'
    exit 0
} elseif ($mpCmdRunRestoreSucceeded) {
    Write-Step (T "DONE · MpCmdRun.exe Restore-All 已執行 (Layer 2 fallback) · 請重啟 Revit · 試 Zigma License paste-activate" `
                  "DONE · MpCmdRun.exe Restore-All executed (Layer 2 fallback) · restart Revit · try Zigma License paste-activate" `
                  "DONE · MpCmdRun.exe Restore-All 実行済み (Layer 2 fallback) · Revit を再起動 · Zigma License paste-activate を試してください") 'Green'
    exit 0
} elseif ($restoreFail -eq 0 -and $restoreOk -gt 0) {
    Write-Step (T "DONE · 全部 restore 成功 · 請重啟 Revit · 試 Zigma License paste-activate" `
                  "DONE · all restored successfully · restart Revit · try Zigma License paste-activate" `
                  "DONE · 全て復元成功 · Revit を再起動 · Zigma License paste-activate を試してください") 'Green'
    exit 0
} elseif ($restoreOk -gt 0) {
    Write-Step (T "PARTIAL · 部分 restore 成功 · 請重啟 Revit 試 · 若仍失敗請聯絡 michael.lin@realitymatrixai.com" `
                  "PARTIAL · some restored successfully · restart Revit and try · if still fails contact michael.lin@realitymatrixai.com" `
                  "PARTIAL · 一部復元成功 · Revit を再起動して試してください · 失敗する場合は michael.lin@realitymatrixai.com までご連絡ください") 'Yellow'
    exit 4
} else {
    # Layer 3 . UI step-by-step manual instructions (FACT . trial user prompt P0)
    # Both Layer 1 (Restore-MpThreat) and Layer 2 (MpCmdRun.exe) failed/unavailable
    Write-Step (T "WARN · 自動 restore 不可用 · 請依下列 UI 步驟手動操作:" `
                  "WARN · auto restore unavailable · please follow UI steps below manually:" `
                  "WARN · 自動 restore 使用不可 · 以下 UI 手順で手動操作してください:") 'Yellow'
    Write-Host ""
    Write-Host (T "  [Step 1] 開啟「Windows 安全性」(開始功能表 → 搜尋 'Windows 安全性')" `
                  "  [Step 1] Open 'Windows Security' (Start menu → search 'Windows Security')" `
                  "  [Step 1] 「Windows セキュリティ」を開く (スタートメニュー → 'Windows セキュリティ' を検索)") -ForegroundColor White
    Write-Host (T "  [Step 2] 點「病毒與威脅防護」 → 「保護歷程記錄」" `
                  "  [Step 2] Click 'Virus & threat protection' → 'Protection history'" `
                  "  [Step 2] 「ウイルスと脅威の防止」 → 「保護の履歴」をクリック") -ForegroundColor White
    Write-Host (T "  [Step 3] 找到 Trojan:Win32/Wacatac.B!ml (Zigma 相關項目)" `
                  "  [Step 3] Find Trojan:Win32/Wacatac.B!ml (Zigma related items)" `
                  "  [Step 3] Trojan:Win32/Wacatac.B!ml を検出 (Zigma 関連項目)") -ForegroundColor White
    Write-Host (T "  [Step 4] 點該項目 → 「動作」 → 「還原」" `
                  "  [Step 4] Click the item → 'Actions' → 'Restore'" `
                  "  [Step 4] 項目をクリック → 「アクション」 → 「復元」") -ForegroundColor White
    Write-Host (T "  [Step 5] 加例外:「管理設定」 → 「排除清單」 → 「新增排除」 → 「資料夾」" `
                  "  [Step 5] Add exclusion: 'Manage settings' → 'Exclusions' → 'Add an exclusion' → 'Folder'" `
                  "  [Step 5] 除外追加:「設定の管理」 → 「除外」 → 「除外の追加」 → 「フォルダー」") -ForegroundColor White
    Write-Host (T "         路徑: C:\Program Files\Autodesk\Revit\Addins\2027\Zigma" `
                  "         Path: C:\Program Files\Autodesk\Revit\Addins\2027\Zigma" `
                  "         パス: C:\Program Files\Autodesk\Revit\Addins\2027\Zigma") -ForegroundColor White
    Write-Host (T "  [Step 6] 完成後重啟 Revit · 試 Zigma License paste-activate" `
                  "  [Step 6] After done restart Revit · try Zigma License paste-activate" `
                  "  [Step 6] 完了後 Revit を再起動 · Zigma License paste-activate を試行") -ForegroundColor White
    Write-Host ""
    Write-Step (T "  若仍失敗請聯絡 michael.lin@realitymatrixai.com (附 Desktop\customer-diagnostic.txt)" `
                  "  If still fails contact michael.lin@realitymatrixai.com (attach Desktop\customer-diagnostic.txt)" `
                  "  失敗する場合は michael.lin@realitymatrixai.com までご連絡ください (Desktop\customer-diagnostic.txt を添付)") 'Yellow'
    exit 0
}
