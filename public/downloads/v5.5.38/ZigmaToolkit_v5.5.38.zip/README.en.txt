================================================================
  Zigma USD Connector · Pre-Beta v5.5.38
  Installation Guide + License Activation Troubleshooting (English)
  Reality Matrix AI Inc. · 2026-05-28
================================================================

NDA CONFIDENTIAL · Do not forward to any third party who has not signed an NDA.

----------------------------------------------------------------
  What's New in v5.5.38 · About Dialog 3-Button Row
----------------------------------------------------------------

   Open Revit -> Zigma USD ribbon -> click "About Zigma". The
   dialog now exposes three new buttons (below the language
   RadioButton row):

     - Diagnostic
       Runs trial-empirical-test.cmd in the background. Writes
       a .txt report to your Desktop and opens a pre-filled email
       draft (with the .txt attached) to
       michael.lin@realitymatrixai.com.

     - Restore Quarantine
       Runs restore-from-defender-quarantine.ps1 with an admin
       UAC prompt. Uses a 3-layer fallback chain:
       PowerShell cmdlet -> MpCmdRun.exe -> manual UI step-by-step.

     - Open README
       Opens the language-matched README.txt (en / zh-TW / ja) in
       Notepad. Always available regardless of license state.

   Default state (v5.5.38):
     - License activated: Diagnostic + Restore Quarantine are
       Disabled (grayed · not needed)
     - License activation FAILED: both buttons Enabled + red
       Step 1 / Step 2 hint guides the user

   Button labels follow the language RadioButton at the top of
   the About dialog (English / 中文 / 日本語) and switch
   instantly. The manual .cmd / .ps1 path is still fully
   supported (see §5).

   NOTE: trial user empirical verification is pending round-3 ·
         not yet 100% guaranteed · if any About-dialog button
         misbehaves, fall back to the manual path in §5.

Other language editions (in this same folder):
   README.zh-TW.txt  (繁體中文)
   README.ja.txt     (日本語)

----------------------------------------------------------------
  Table of Contents
----------------------------------------------------------------

    §1  System Requirements
    §2  Installation
    §3  Launch Verification
    §4  License Activation Flow
    §5  Troubleshooting
        §5.1  License Activation Fails · Red Banner "Defender Quarantine" Recovery Window
        §5.2  License Activation Fails · Orange Banner "License Code Length Error"
        §5.3  Revit Does Not Show the Zigma Ribbon
        §5.4  3D Viewer Crashes on Launch
    §6  Uninstall
    §7  Contact Support
    §8  NDA Reminder

================================================================
  ⚠ §1.0 PRE-INSTALL CHECKLIST (CRITICAL · DO BEFORE MSI)
================================================================

The v5.5.38+ MSI installer auto-checks all 4 prerequisites and
will BLOCK install with an actionable modal if anything is missing.
But it's faster to verify these UPFRONT before running the MSI.

REQUIRED BEFORE INSTALL:

  [ ] (1) Autodesk Revit 2027 installed
          Path: C:\Program Files\Autodesk\Revit 2027\Revit.exe
          (Earlier Revit versions are NOT supported)

  [ ] (2) Revit 2027 NOT running
          Close ALL Revit windows. Verify in Task Manager:
            Ctrl+Shift+Esc -> Processes -> No "Revit.exe" entry
          The MSI will auto-prompt you to close Revit if detected,
          but starting clean avoids file-lock complications.

  [ ] (3) Microsoft Visual C++ 2022 Redistributable (x64) installed
          Download: https://aka.ms/vs/17/release/vc_redist.x64.exe
          Verify in PowerShell:
            Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\VisualStudio\14.0\VC\Runtimes\x64' |
                Select Version, Installed
            Expected: Installed = 1 · Version >= 14.32
          WHY: ZigmaRenderUtil.dll (native C++) loads VC++ runtime DLLs.
               Without VC++ Redist: HRESULT 0x8007007E ERROR_MOD_NOT_FOUND
               at License activation time.

  [ ] (4) Microsoft .NET 10 Desktop Runtime (x64) installed
          Download: https://dotnet.microsoft.com/download/dotnet/10.0
          Select: ".NET Desktop Runtime 10.0" · x64
          Verify in PowerShell:
            dotnet --list-runtimes
            Expected: Microsoft.WindowsDesktop.App 10.0.0 (or later)
          WHY: Plugin (Zigma.UsdConnector.dll) is .NET 10 WPF managed code.
               Without .NET 10 Desktop Runtime: Plugin fails to load in Revit.

  [ ] (5) Administrator rights (UAC prompt during MSI install)

  [ ] (6) ~600 MB free disk space on C:\

What happens if you SKIP a prerequisite:
  - MSI v5.5.38+ shows 3-language modal with:
      WHAT is missing + Download URL + 3-step recovery
  - Install is BLOCKED until prerequisite installed
  - No partial install · no broken state

After install, v5.5.38+ Plugin OnStartup PreActivationPrerequisiteVerifier
(PAPV) runs 6 runtime probes and shows a colored banner in About Dialog:
  Green = all OK · Yellow = warnings · Red = critical fix needed

----------------------------------------------------------------

================================================================
  §1 System Requirements (Detail)
================================================================

>>> 1.1 Operating System
   - Windows 11 (recommended · fully tested · Defender PUA path OK)
   - Windows 10 22H2 or later

>>> 1.2 Required Software (matches §1.0 checklist above)

   | # | Item                            | Version Required | Download URL                                          |
   |---|---------------------------------|------------------|-------------------------------------------------------|
   | 1 | Autodesk Revit                  | 2027 (only)      | (commercial · purchase from Autodesk)                 |
   | 2 | .NET 10 Desktop Runtime (x64)   | 10.0.0+          | https://dotnet.microsoft.com/download/dotnet/10.0    |
   | 3 | Visual C++ 2022 Redistributable | x64 latest       | https://aka.ms/vs/17/release/vc_redist.x64.exe       |

>>> 1.3 Hardware Recommendations
   - CPU: 8 cores or more (Intel i7 / AMD Ryzen 7 or higher)
   - RAM: 16 GB or more (32 GB recommended for large RVT models)
   - Disk: approximately 600 MB free space
   - GPU: DirectX 11 capable (required by the 3D Viewer)

>>> 1.4 Confirm .NET 10 Desktop Runtime Is Installed

   Run in PowerShell:
      dotnet --list-runtimes

   You should see output similar to:
      Microsoft.WindowsDesktop.App 10.0.0 [...]

   If it is not installed, visit https://dotnet.microsoft.com/download/dotnet/10.0
   and download ".NET Desktop Runtime 10.0" (x64).

----------------------------------------------------------------
  §2 Installation
----------------------------------------------------------------

>>> 2.1 Pre-Install Preparation
   1. Fully close Revit 2027 (verify in Task Manager that no Revit.exe is running).
   2. Confirm Revit is installed at C:\Program Files\Autodesk\Revit 2027\

   Defender exclusion notes (handled automatically by the MSI in most cases):

      During v5.5.38 MSI install, seven Defender exclusion paths are added
      automatically (WiX CustomAction · no manual action needed).

      If your corporate environment locks Microsoft Defender via GPO,
      the automatic exclusion may be ineffective. In that case, run the
      following from an Administrator PowerShell prompt:

         Add-MpPreference -ExclusionPath "C:\Program Files\Autodesk\Revit\Addins\2027"
         Add-MpPreference -ExclusionPath "C:\Program Files\Autodesk\Revit\Addins\2027\Zigma"

>>> 2.2 Run the MSI Installer
   1. Double-click "ZigmaSetup_v5.5.38_Pre-Beta.msi".
   2. At the UAC prompt, click "Yes" (perMachine install · admin rights required).
   3. Read the Pre-Beta NDA EULA and tick "I agree".
   4. Confirm the default install path and click "Install".
   5. Installation takes approximately 1-3 minutes (depends on disk speed).

>>> 2.3 Verify Installation

   Open File Explorer and confirm the following files exist:

      C:\Program Files\Autodesk\Revit\Addins\2027\
      ├── Zigma.UsdConnector.addin              ← Revit manifest (at root)
      └── Zigma\                                 ← Plugin files in vendor subfolder
          ├── Zigma.UsdConnector.dll
          ├── ZigmaRenderUtil.dll
          ├── tools\                            ← Troubleshooting toolkit
          │   ├── README.txt                   (index · 3-language entry point)
          │   ├── README.zh-TW.txt             (Traditional Chinese)
          │   ├── README.en.txt                (this file)
          │   ├── README.ja.txt                (Japanese)
          │   ├── customer-diagnostic.cmd
          │   ├── customer-diagnostic.ps1
          │   └── restore-from-defender-quarantine.ps1
          ├── dist\workers\zigma-worker.exe
          └── ZigmaWpfViewer\ZigmaWpfViewer.exe

   Note: %PROGRAMFILES% is normally C:\Program Files (perMachine x64 install · administrator privileges required to modify).

----------------------------------------------------------------
  §3 Launch Verification
----------------------------------------------------------------

>>> 3.1 Open Revit 2027 and create or open any project.

>>> 3.2 Confirm the Zigma Ribbon
   Switch to the "Add-Ins" tab. You should see a "Zigma USD" panel containing:
      - Export to USD
      - Import from USD
      - 3D Viewer
      - About Zigma

>>> 3.3 Confirm Version Information
   Click "About Zigma" and the dialog should show:
      Version: 5.5.38-release+3A17861E
      Build  : Pre-Beta

----------------------------------------------------------------
  §4 License Activation Flow
----------------------------------------------------------------

>>> 4.1 Obtain Your Machine Code
   1. About Zigma -> click "Activate License".
   2. The Machine Code text window shows a string and copies it to the clipboard automatically.
   3. Email the Machine Code to michael.lin@realitymatrixai.com to receive your license.txt file.

>>> 4.2 Paste the License and Activate

   IMPORTANT: The license MUST be received as a .txt attachment.
              Do NOT copy it out of Evernote / Word / Notion / OneNote
              (rich-text middleware will silently truncate it).

   1. Save the license.txt attachment to your Desktop.
   2. Open it with Windows Notepad.
   3. Ctrl+A to select all -> Ctrl+C to copy.
   4. About Zigma -> License box -> Ctrl+V to paste.
   5. Click "Paste & Activate".
   6. A green message "License activated successfully!" means success.

>>> 4.3 Activation Failed?
   See §5 Troubleshooting.

----------------------------------------------------------------
  §5 Troubleshooting
----------------------------------------------------------------

>>> §5.1 Red Banner "Defender Quarantine" Recovery Window

   Symptom:
      The About dialog shows a red banner: "Important Zigma components
      were mistakenly quarantined by Microsoft Defender · please see the
      recovery window." At the same time a separate popup appears titled
      "Microsoft Defender Quarantine Detected". After clicking OK the
      tools folder opens automatically in Explorer.

   Cause:
      Microsoft Defender mistakenly detects Trojan:Win32/Wacatac.B!ml
      against Zigma native components. The affected files are removed from
      disk, causing the Plugin's license activation to fail at startup.

   Recovery (3 steps):

   --- Step 1 · Run the diagnostic tool (read-only · no admin needed) ---

      1.1 Explorer should already be open at the tools\ folder. If not,
          navigate there manually:
            C:\Program Files\Autodesk\Revit\Addins\2027\Zigma\tools\
      1.2 Double-click "customer-diagnostic.cmd".
      1.3 Wait approximately 30 seconds. A file named
          "Zigma-Diagnostic-<ComputerName>-<Timestamp>.txt" appears on the Desktop.
      1.4 Notepad opens the report automatically.

   --- Step 2 · Run the Defender restore script (admin required) ---

      2.1 Fully close Revit 2027 (verify in Task Manager that no Revit.exe is running).
      2.2 Start menu -> search for "PowerShell".
      2.3 Right-click "Windows PowerShell" -> "Run as administrator".
      2.4 Accept the UAC prompt.
      2.5 Change directory to the tools folder:

             cd "C:\Program Files\Autodesk\Revit\Addins\2027\Zigma\tools"

      2.6 Run:

             .\restore-from-defender-quarantine.ps1

      2.7 Check the result:
            "DONE · all restores succeeded"       -> Success · go to Step 3.
            "FAIL · Restore-MpThreat all failed"  -> Go to manual restore (2.8).

      2.8 Manual restore (only if 2.7 failed):
             - Windows + I -> Privacy & Security -> Windows Security
             - Virus & Threat Protection -> Protection History
             - Locate entries related to "Trojan:Win32/Wacatac.B!ml"
             - Click the entry -> Actions -> "Allow" (or "Restore")

   --- Step 3 · Restart Revit and retry license activation ---

      3.1 Open Revit 2027.
      3.2 Zigma USD tab -> About -> Paste & Activate.
      3.3 A green message "License activated successfully!" means success.

   Still failing?
      Email "Zigma-Diagnostic-*.txt" (from your Desktop) to
      michael.lin@realitymatrixai.com
      Subject format: [Zigma Pre-Beta v5.5.38] <brief description>

>>> §5.2 Orange Banner "License Code Length Error"

   Symptom:
      The About dialog shows an orange banner: "License code length error ·
      received XXX chars · expected 780 chars · please re-paste using the .txt
      attachment (do NOT copy from Evernote / Word / Notion)".

   Cause:
      The license string was truncated or rewritten in transit by
      rich-text middleware (Evernote ENML / Word auto-format /
      Notion / OneNote, etc.).

   Recovery:
   1. Re-obtain the license from the original .txt attachment (see §4.2).
      - Do NOT copy from Evernote / Word / Notion / OneNote.
      - You MUST open the .txt file with Windows Notepad.
      - Ctrl+A to select all -> Ctrl+C to copy (confirm the length is 780 chars).
   2. About Zigma -> License box -> Ctrl+V -> Paste & Activate.

   If it still fails repeatedly, email a re-send request to:
      michael.lin@realitymatrixai.com
      Subject: [Zigma Pre-Beta v5.5.38] Please re-send License (.txt attachment)

>>> §5.3 Revit Does Not Show the Zigma Ribbon

   Symptom: The Revit 2027 "Add-Ins" tab does not show a Zigma USD group.

   Resolution:
   1. Confirm the following file exists:
         C:\Program Files\Autodesk\Revit\Addins\2027\Zigma.UsdConnector.addin
   2. Revit Notification Center (bell icon in the top-right) -> check for
      Add-In load failure messages.
   3. Confirm .NET 10 Desktop Runtime is installed (see §1.4).
   4. Fully close Revit (verify in Task Manager that no Revit.exe is running)
      and relaunch.

>>> §5.4 3D Viewer Crashes on Launch

   Symptom: Clicking "3D Viewer" causes ZigmaWpfViewer.exe to crash
            immediately, or a .NET error dialog appears.

   Resolution:
   1. Confirm .NET 10 Desktop Runtime is installed (dotnet --list-runtimes).
   2. If missing, download from https://dotnet.microsoft.com/download/dotnet/10.0
   3. If it still crashes, please provide the following files to support:
      - %LOCALAPPDATA%\Zigma\logs\ZigmaSystemLog.log
      - A screenshot of the Windows Event Viewer .NET Runtime error

----------------------------------------------------------------
  §6 Uninstall
----------------------------------------------------------------

>>> 6.1 Standard Uninstall
   1. Settings -> Apps -> Installed Apps
   2. Search for "Zigma".
   3. Click the "..." next to "Zigma USD<->Revit Converter" -> "Uninstall".
   4. UAC -> Yes -> wait 30-60 seconds.

>>> 6.2 Per-User Residual Cleanup (run as the affected user):

      Remove-Item -Recurse -Force "$env:APPDATA\Zigma" -ErrorAction SilentlyContinue
      Remove-Item -Recurse -Force "$env:LOCALAPPDATA\Zigma" -ErrorAction SilentlyContinue
      Remove-Item -Force "$env:USERPROFILE\.config\zigma_config.cfg" -ErrorAction SilentlyContinue

>>> 6.3 Remove Defender Exclusions (optional):

      Remove-MpPreference -ExclusionPath "C:\Program Files\Autodesk\Revit\Addins\2027"
      Remove-MpPreference -ExclusionPath "C:\Program Files\Autodesk\Revit\Addins\2027"

----------------------------------------------------------------
  §7 Contact Support
----------------------------------------------------------------

   Michael Lin · Founder, Reality Matrix AI Inc.
      Email         : michael.lin@realitymatrixai.com
      Response time : Within 24 hours on business days (Taipei time, UTC+8)

   Email subject format: [Zigma Pre-Beta v5.5.38] <brief description>

   Please include in your message:
      1. Your name + company
      2. OS version (run winver to check)
      3. Revit 2027 version number (Revit -> Help -> About)
      4. Problem description + reproduction steps
      5. Relevant logs / screenshots (if available)
      6. (License activation failures) the Zigma-Diagnostic-*.txt file from your Desktop

   Prohibited actions:
      - Do NOT post Zigma-related questions on any public forum
        (GitHub Issues / Autodesk Forum / Reddit / Facebook).
      - Do NOT ask via social media (public LINE / Discord channels).
      - Do NOT forward the MSI or license file to any third party
        who has not signed an NDA.

----------------------------------------------------------------
  §8 NDA Reminder
----------------------------------------------------------------

   You accepted the Pre-Beta NDA EULA during the MSI install. Key points:

   1. The product's internal workings, performance numbers, bugs, and
      unreleased features are CONFIDENTIAL.
   2. Disassembly / reverse engineering / modification of protected binaries
      is PROHIBITED.
   3. Internal test screenshots and recordings are for your personal
      testing only · must NOT be publicly distributed.
   4. Do NOT publicly benchmark or compare Zigma against competing products.
   5. Customer-confidential RVT models must NOT be transmitted · please
      reproduce issues using anonymized sample RVT files.

   NDA term: Remains in effect until Zigma is publicly released
            (target: 2026 Q3-Q4).

   Consequences of violation (per EULA §0.4):
      - Immediate termination of Pre-Beta testing privileges.
      - Reality Matrix AI Inc. reserves the right to pursue civil and
        criminal remedies.

================================================================
(C) 2026 Reality Matrix AI Inc. · All rights reserved.
================================================================
