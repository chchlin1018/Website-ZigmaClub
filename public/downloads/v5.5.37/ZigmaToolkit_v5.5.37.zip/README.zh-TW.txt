================================================================
  Zigma USD Connector · Pre-Beta v5.5.37
  安裝指南 + License 啟動故障排除 (繁體中文)
  Reality Matrix AI Inc. · 實矩科技 · 2026-05-28
================================================================

⚠️ NDA 機密 · 不得轉發予未簽 NDA 之第三方

────────────────────────────────────────────────────────────────
  v5.5.37 新功能 · About Dialog 一鍵診斷 / 還原 / 回報
────────────────────────────────────────────────────────────────

   開 Revit -> Zigma USD ribbon -> 點「About Zigma」· 對話框內
   新增 3 個按鈕 (位於語言 RadioButton 下方):

     • Diagnostic (一鍵診斷)
       內部執行 trial-empirical-test.cmd · 寫桌面 .txt 報告 +
       自動開 Email 草稿並附檔給 michael.lin@realitymatrixai.com。

     • Restore Quarantine (還原 Defender 隔離)
       內部執行 restore-from-defender-quarantine.ps1 (UAC 提示) ·
       三層 fallback chain: PS cmdlet -> MpCmdRun.exe -> 手動 UI 步驟。

     • Open README (開啟說明)
       開啟對應語言 README.txt (英 / 繁中 / 日) · Notepad 顯示。
       任何時候皆可使用 · 不受 License 啟動狀態影響。

   預設行為 (v5.5.37):
     • License 已啟動: Diagnostic + Restore Quarantine 為 Disabled (灰色)
     • License 啟動失敗: 兩按鈕 Enabled + 紅字 Step 1/Step 2 引導

   按鈕語言隨對話框上方 RadioButton (English / 中文 / 日本語)
   即時切換。.cmd / .ps1 手動執行 path 仍完整保留 (見 §5)。

   ⚠️ trial user empirical verification pending round-3 ·
      not yet 100% guaranteed · 若 About Dialog 按鈕失靈
      請改用 §5 手動 path。

────────────────────────────────────────────────────────────────
  目錄
────────────────────────────────────────────────────────────────

    §1  系統需求
    §2  安裝
    §3  啟動驗證
    §4  License 啟動流程
    §5  故障排除
        §5.1  License 啟動失敗 · 紅字「Defender 隔離」修復視窗
        §5.2  License 啟動失敗 · 橙字「啟動碼長度錯誤」
        §5.3  Revit 找不到 Zigma 工具列
        §5.4  3D Viewer 啟動崩潰
    §6  解除安裝
    §7  聯絡支援
    §8  NDA 提醒

================================================================
  ⚠ §1.0 安裝前檢查清單 (CRITICAL · MSI 之前必做)
================================================================

v5.5.37+ MSI installer 自動檢查 4 個 prerequisite · 缺則
彈出 actionable 3-lang modal 阻擋安裝。事前準備好可省 cycle。

安裝前必備:

  [ ] (1) Autodesk Revit 2027 已安裝
          路徑: C:\Program Files\Autodesk\Revit 2027\Revit.exe
          (Revit 2026 及更早版本不支援)

  [ ] (2) Revit 2027 完全關閉
          關閉所有 Revit 視窗 · 工作管理員確認:
            Ctrl+Shift+Esc -> 處理程序 -> 無 "Revit.exe" 項目
          MSI 會自動 prompt 您關閉 Revit · 但事前關閉避免檔案鎖定。

  [ ] (3) Microsoft Visual C++ 2022 Redistributable (x64) 已安裝
          下載: https://aka.ms/vs/17/release/vc_redist.x64.exe
          PowerShell 驗證:
            Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\VisualStudio\14.0\VC\Runtimes\x64' |
                Select Version, Installed
            預期: Installed = 1 · Version >= 14.32
          原因: ZigmaRenderUtil.dll (native C++) 需 VC++ runtime DLLs。
                沒裝 VC++ Redist: License 啟動時 HRESULT 0x8007007E
                ERROR_MOD_NOT_FOUND。

  [ ] (4) Microsoft .NET 10 Desktop Runtime (x64) 已安裝
          下載: https://dotnet.microsoft.com/download/dotnet/10.0
          選擇: ".NET Desktop Runtime 10.0" · x64
          PowerShell 驗證:
            dotnet --list-runtimes
            預期: Microsoft.WindowsDesktop.App 10.0.0 (或更新)
          原因: Plugin (Zigma.UsdConnector.dll) 為 .NET 10 WPF managed code。
                沒裝 .NET 10 Desktop Runtime: Plugin 無法在 Revit 載入。

  [ ] (5) 系統管理員權限 (MSI 安裝時會彈 UAC)

  [ ] (6) C:\ 至少 600 MB 可用空間

若 SKIP 任何 prerequisite:
  - MSI v5.5.37+ 顯示 3-lang modal:
      缺什麼 + 下載 URL + 3-step 修復步驟
  - 安裝被 BLOCK 直到 prerequisite 裝好

裝好後 · v5.5.37+ Plugin OnStartup PAPV 跑 6 runtime probes ·
About Dialog 彩色 banner:綠 = 全 OK · 黃 = warning · 紅 = critical

----------------------------------------------------------------

================================================================
  §1 系統需求 (詳細)
================================================================

>>> 1.1 作業系統
   • Windows 11 (推薦 · 已完整測試)
   • Windows 10 22H2 或更新版本

>>> 1.2 必要軟體

   | 項目                            | 版本需求      | 備註                |
   |---------------------------------|---------------|---------------------|
   | Autodesk Revit                  | 2027 (唯一支援) | 不支援 2026 或更早    |
   | .NET 10 Desktop Runtime         | 10.0.0+       | Plugin + Viewer 必要 |
   | Visual C++ 2022 Redistributable | x64 最新版    | Worker 必要         |

>>> 1.3 硬體建議
   • CPU: 8 核心以上 (Intel i7 / AMD Ryzen 7 或更高)
   • RAM: 16 GB 以上 (推薦 32 GB · 大型 RVT 模型)
   • 磁碟: 約 600 MB 可用空間
   • GPU: 支援 DirectX 11 (3D Viewer 需要)

>>> 1.4 確認 .NET 10 Desktop Runtime 已安裝

   PowerShell 執行:
      dotnet --list-runtimes

   應看到類似輸出:
      Microsoft.WindowsDesktop.App 10.0.0 [...]

   若未安裝 · 至 https://dotnet.microsoft.com/download/dotnet/10.0
   下載 ".NET Desktop Runtime 10.0" (x64) 並安裝。

────────────────────────────────────────────────────────────────
  §2 安裝
────────────────────────────────────────────────────────────────

>>> 2.1 安裝前準備
   1. 完全關閉 Revit 2027 (Task Manager 確認無 Revit.exe)
   2. 確認 Revit 安裝於 C:\Program Files\Autodesk\Revit 2027\

   ⚠️ Defender 例外設定 (大部分情境 MSI 自動處理):

      v5.5.37 MSI 安裝時會自動加入 7 條 Defender 排除路徑
      (WiX CustomAction · 不需用戶手動操作)。

      若您所在企業環境 Defender 由 GPO 鎖定 · 自動排除可能失效。
      此情況請以系統管理員 PowerShell 手動執行:

         Add-MpPreference -ExclusionPath "C:\Program Files\Autodesk\Revit\Addins\2027"
         Add-MpPreference -ExclusionPath "C:\Program Files\Autodesk\Revit\Addins\2027\Zigma"

>>> 2.2 執行 MSI 安裝程式
   1. 雙擊 "ZigmaSetup_v5.5.37_Pre-Beta.msi"
   2. UAC 提示 → 按「是」(perMachine 安裝 · 需管理員權限)
   3. 閱讀 Pre-Beta NDA EULA → 勾「我同意」
   4. 確認安裝路徑為預設值 · 按「Install」
   5. 安裝過程約 1-3 分鐘 (依磁碟速度)

>>> 2.3 驗證安裝完成

   開啟檔案總管 · 確認以下檔案存在:

      C:\Program Files\Autodesk\Revit\Addins\2027\
      ├── Zigma.UsdConnector.addin              ← Revit manifest (位於根目錄)
      └── Zigma\                                 ← Plugin 檔案位於 vendor 子資料夾
          ├── Zigma.UsdConnector.dll
          ├── ZigmaRenderUtil.dll
          ├── tools\                            ← Troubleshooting 工具
          │   ├── README.txt                   (index · 3 語言入口)
          │   ├── README.zh-TW.txt             (本檔)
          │   ├── README.en.txt
          │   ├── README.ja.txt
          │   ├── customer-diagnostic.cmd
          │   ├── customer-diagnostic.ps1
          │   └── restore-from-defender-quarantine.ps1
          ├── dist\workers\zigma-worker.exe
          └── ZigmaWpfViewer\ZigmaWpfViewer.exe

   注: %PROGRAMFILES% 通常為 C:\Program Files (perMachine x64 install · 需管理員權限才能修改)

────────────────────────────────────────────────────────────────
  §3 啟動驗證
────────────────────────────────────────────────────────────────

>>> 3.1 開啟 Revit 2027 並建/開任意專案

>>> 3.2 確認 Zigma 工具列
   切換至「附加模組」(Add-Ins) 頁籤 · 應看到「Zigma USD」面板:
      • Export to USD
      • Import from USD
      • 3D Viewer
      • About Zigma

>>> 3.3 確認版本資訊
   點「About Zigma」對話框應顯示:
      Version: 5.5.37-release+3A17861E
      Build  : Pre-Beta

────────────────────────────────────────────────────────────────
  §4 License 啟動流程
────────────────────────────────────────────────────────────────

>>> 4.1 取得 Machine Code
   1. About Zigma → 「Activate License」
   2. Machine Code 文字視窗顯示一串字串 · 自動複製到 clipboard
   3. Email 寄至 michael.lin@realitymatrixai.com 取得授權檔 license.txt

>>> 4.2 貼上 License 啟動

   ⚠️ License 必須以 .txt 附件形式收到
       不要從 Evernote / Word / Notion / OneNote 複製 (會被砍字)

   1. 下載 license.txt 附件到桌面
   2. 用「記事本」(Notepad) 開啟
   3. Ctrl+A 全選 → Ctrl+C 複製
   4. About Zigma → License box → Ctrl+V 貼上
   5. 按「Paste & Activate」
   6. 看到綠字「License activated successfully!」= 成功

>>> 4.3 啟動失敗?
   見 §5 故障排除。

────────────────────────────────────────────────────────────────
  §5 故障排除
────────────────────────────────────────────────────────────────

>>> §5.1 紅字「Defender 隔離」修復視窗

   症狀:
      About Dialog 顯紅字「重要 Zigma 元件被 Microsoft Defender
      誤判隔離 · 請看修復視窗」· 同時跳出獨立彈窗「Microsoft
      Defender Quarantine Detected」· 按 OK 後自動開啟 tools 資料夾。

   原因:
      Microsoft Defender 對 Zigma native 元件觸發 Trojan:Win32/
      Wacatac.B!ml 誤判隔離 · 元件從磁碟移除 ·
      Plugin 啟動 License 失敗。

   修復步驟 (3 個):

   --- 步驟 1 · 跑診斷工具 (read-only · 不需 admin) ---

      1.1 (Explorer 已自動開啟到 tools\ 資料夾 · 若未開請手動 navigate)
            C:\Program Files\Autodesk\Revit\Addins\2027\Zigma\tools\
      1.2 雙擊「customer-diagnostic.cmd」
      1.3 等約 30 秒 · 桌面產生「Zigma-Diagnostic-<電腦名>-<時間>.txt」
      1.4 Notepad 自動開啟報告

   --- 步驟 2 · 跑 Defender 還原工具 (需 admin) ---

      2.1 完全關閉 Revit 2027 (Task Manager 確認無 Revit.exe)
      2.2 開始功能表 → 搜尋「PowerShell」
      2.3 右鍵「Windows PowerShell」→「以系統管理員身分執行」
      2.4 接受 UAC 提示
      2.5 cd 切換到 tools 資料夾:

             cd "C:\Program Files\Autodesk\Revit\Addins\2027\Zigma\tools"

      2.6 執行:

             .\restore-from-defender-quarantine.ps1

      2.7 看結果:
            「DONE · 全部 restore 成功」 → 成功 · 跳步驟 3
            「FAIL · Restore-MpThreat 全失敗」 → 跳「手動還原」 (步驟 2.8)

      2.8 手動還原 (僅在 2.7 FAIL 時):
             • Windows + I → 隱私權與安全性 → Windows 安全性
             • 病毒與威脅防護 → 保護歷程記錄
             • 找到「Trojan:Win32/Wacatac.B!ml」相關項目
             • 點該項目 → 動作 →「允許」(或「還原」)

   --- 步驟 3 · 重啟 Revit 試 License 啟動 ---

      3.1 開啟 Revit 2027
      3.2 Zigma USD tab → About → Paste & Activate
      3.3 看到綠字「License activated successfully!」= 成功

   仍失敗?
      將「Zigma-Diagnostic-*.txt」Email 寄至
      michael.lin@realitymatrixai.com (主旨格式: [Zigma Pre-Beta v5.5.37] <簡述>)

>>> §5.2 橙字「啟動碼長度錯誤」

   症狀:
      About Dialog 顯橙字「啟動碼長度錯誤 · 收到 XXX 字 · 應為 780 字 ·
      請改用 .txt 附件「重新貼上」(不要從 Evernote / Word / Notion 複製)」

   原因:
      License 字串在傳輸過程被 rich-text middleware (Evernote ENML /
      Word auto-format / Notion / OneNote 等) 縮短或改寫。

   修復:
   1. 重新從 .txt 附件取得 license (見 §4.2)
      • 不要從 Evernote / Word / Notion / OneNote 複製
      • 必須用 Windows 記事本 (Notepad) 開 .txt
      • Ctrl+A 全選 → Ctrl+C 複製 (確認長度 780 字)
   2. About Zigma → License box → Ctrl+V → Paste & Activate

   多次失敗 · 來信請求重新發送:
      michael.lin@realitymatrixai.com
      主旨: [Zigma Pre-Beta v5.5.37] 請重新發送 License (.txt 附件)

>>> §5.3 Revit 找不到 Zigma 工具列

   症狀: Revit 2027「附加模組」頁籤無 Zigma USD 群組。

   解決:
   1. 確認以下檔案存在:
         C:\Program Files\Autodesk\Revit\Addins\2027\Zigma.UsdConnector.addin
   2. Revit 通知中心 (右上鈴鐺圖示) → 檢查 Add-In 載入失敗訊息
   3. 確認 .NET 10 Desktop Runtime 已安裝 (見 §1.4)
   4. 完全關閉 Revit (Task Manager 確認無 Revit.exe) → 重新啟動

>>> §5.4 3D Viewer 啟動崩潰

   症狀: 點「3D Viewer」後 ZigmaWpfViewer.exe 立即崩潰 ·
        或出現 .NET 錯誤對話框。

   解決:
   1. 確認 .NET 10 Desktop Runtime 已安裝 (dotnet --list-runtimes)
   2. 若缺 · 下載 https://dotnet.microsoft.com/download/dotnet/10.0
   3. 仍崩潰 · 提供以下檔案給支援:
      • %LOCALAPPDATA%\Zigma\logs\ZigmaSystemLog.log
      • Windows 事件檢視器 .NET Runtime 錯誤截圖

────────────────────────────────────────────────────────────────
  §6 解除安裝
────────────────────────────────────────────────────────────────

>>> 6.1 標準解除安裝
   1. 設定 → 應用程式 → 已安裝的應用程式
   2. 搜尋「Zigma」
   3. 點「Zigma USD↔Revit Converter」旁 ⋯ → 「解除安裝」
   4. UAC → 是 → 等 30-60 秒

>>> 6.2 多用戶殘留清除 (以該用戶身分執行):

      Remove-Item -Recurse -Force "$env:APPDATA\Zigma" -ErrorAction SilentlyContinue
      Remove-Item -Recurse -Force "$env:LOCALAPPDATA\Zigma" -ErrorAction SilentlyContinue
      Remove-Item -Force "$env:USERPROFILE\.config\zigma_config.cfg" -ErrorAction SilentlyContinue

>>> 6.3 移除 Defender 排除 (選擇性):

      Remove-MpPreference -ExclusionPath "C:\Program Files\Autodesk\Revit\Addins\2027"
      Remove-MpPreference -ExclusionPath "C:\Program Files\Autodesk\Revit\Addins\2027"

────────────────────────────────────────────────────────────────
  §7 聯絡支援
────────────────────────────────────────────────────────────────

   Michael Lin (林志錚) · Reality Matrix AI Inc. 創辦人 · 實矩科技
      Email   : michael.lin@realitymatrixai.com
      回覆時間: 工作日 24 小時內 (台北時間 UTC+8)

   ⚠️ Email 主旨格式: [Zigma Pre-Beta v5.5.37] <簡述問題>

   內容請含:
      1. 您的姓名 + 公司
      2. 作業系統版本 (winver 查詢)
      3. Revit 2027 版本號 (Revit → 說明 → 關於)
      4. 問題描述 + 重現步驟
      5. 相關日誌 / 截圖 (有的話)
      6. (License 啟動失敗) 桌面 Zigma-Diagnostic-*.txt

   ⚠️ 禁止行為:
      • 不在公開論壇 (GitHub Issues / Autodesk Forum / Reddit /
        Facebook) 張貼 Zigma 相關問題
      • 不透過社群媒體 (公開 LINE / Discord) 詢問
      • 不轉發 MSI 或授權檔予未簽 NDA 之第三方

────────────────────────────────────────────────────────────────
  §8 NDA 提醒
────────────────────────────────────────────────────────────────

   您已於 MSI 安裝過程接受 Pre-Beta NDA EULA · 重點:

   1. 產品內部運作機制、效能數據、Bug、未發布功能 = 機密
   2. 不得反組譯 / 逆向工程 / 修改受保護之二進位
   3. 內部測試截圖/錄影限個人測試用 · 不得公開散佈
   4. 不得以 Zigma 為基準與競品公開比較
   5. 客戶機密 RVT 模型不可傳送 · 請以脫敏範本 RVT 重現問題

   NDA 期限: 至 Zigma 公開正式發布前持續有效 (預計 2026 Q3-Q4)

   違反後果 (per EULA §0.4):
      • 立即終止 Pre-Beta 測試資格
      • Reality Matrix AI Inc. 保留追訴民/刑事責任之權利

================================================================
(C) 2026 Reality Matrix AI Inc. · 實矩科技 · All rights reserved.
================================================================
