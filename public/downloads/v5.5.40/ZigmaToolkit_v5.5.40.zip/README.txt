================================================================
  Zigma USD Connector · Pre-Beta v5.5.40 · README Index
  Installation Guide + License Troubleshooting
  Reality Matrix AI Inc. · 實矩科技 · 2026-05-27
================================================================

⚠️ NDA CONFIDENTIAL · 不得轉發予未簽 NDA 之第三方
   NDA CONFIDENTIAL · Do not forward to non-NDA third parties
   NDA 機密 · NDA 未締結の第三者への転送禁止

────────────────────────────────────────────────────────────────
  ⚠ BEFORE MSI INSTALL · 安裝前必讀 · インストール前必読
────────────────────────────────────────────────────────────────

   Required pre-requisites (v5.5.40+ MSI auto-blocks if missing):
   必要條件 (v5.5.40+ MSI 自動阻擋安裝若缺項):
   必要前提条件 (v5.5.40+ MSI が不足時に自動ブロック):

     (1) Autodesk Revit 2027 installed · 已安裝 · インストール済
     (2) Revit 2027 fully closed · 完全關閉 · 完全終了
     (3) .NET 10 Desktop Runtime
     (4) Visual C++ 2022 Redistributable (x64)
     (5) Administrator access · 管理員權限 · 管理者権限
     (6) ~600 MB disk space free · 磁碟空間 · ディスク空き容量

   Full verification commands & download links · 完整驗證指令與下載連結:
   →  see §1.0 PRE-INSTALL CHECKLIST in your language README below

────────────────────────────────────────────────────────────────
  Please open the README in your preferred language:
  請開啟您慣用語言的 README:
  ご希望の言語の README を開いてください:
────────────────────────────────────────────────────────────────

   繁體中文   →   README.zh-TW.txt
   English    →   README.en.txt
   日本語     →   README.ja.txt

────────────────────────────────────────────────────────────────

Files in this folder · 本資料夾包含 · このフォルダの内容:

   README.txt                                · Index (this file)
   README.zh-TW.txt                          · 繁體中文完整指南
   README.en.txt                             · English full guide
   README.ja.txt                             · 日本語完全ガイド

   customer-diagnostic.cmd                   · 一鍵診斷 / Diagnostic launcher / 診断ランチャー
   customer-diagnostic.ps1                   · 診斷腳本 / Diagnostic script / 診断スクリプト
   restore-from-defender-quarantine.ps1      · Defender 還原 / Defender restore / Defender 復元

────────────────────────────────────────────────────────────────

Common scenarios covered in README · 三語言 README 涵蓋主題:

   • Installation (system requirements / MSI install / verify)
   • License activation (.txt attachment paste-activate flow)
   • Troubleshooting:
       - Microsoft Defender mistakenly quarantined files - recovery
       - License text length mismatch repair
       - Revit ribbon not appearing
       - 3D Viewer crash
   • Uninstall instructions
   • NDA reminder

────────────────────────────────────────────────────────────────
(C) 2026 Reality Matrix AI Inc. · 實矩科技 · All rights reserved.
================================================================
